package areatags;

import com.graphhopper.GraphHopper;
import com.graphhopper.config.Profile;
import com.graphhopper.routing.ev.DefaultImportRegistry;
import com.graphhopper.util.GHUtility;
import com.graphhopper.util.JsonFeatureCollection;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

import static org.junit.Assert.*;

public class AreaTagsTest {

    @Test
    public void namesBecomeAreaPrefixedEncodedValues() {
        assertEquals("area_ulez", AreaTags.encodedValueName("ulez"));
        assertEquals("area_zone_2", AreaTags.encodedValueName("zone_2"));
    }

    @Test
    public void badNamesAreRejected() {
        for (String bad : new String[]{"ULEZ", "2zone", "zone-a", "zone__a", "zone_", ""}) {
            try {
                AreaTags.encodedValueName(bad);
                fail("accepted " + bad);
            } catch (IllegalArgumentException expected) {
            }
        }
    }

    @Test
    public void registryKnowsAreaNamesAndFallsBack() throws Exception {
        AreaTags tags = AreaTags.of(collection("zone", "{\"type\":\"Polygon\",\"coordinates\":[[[1.5,42.5],[1.6,42.5],[1.6,42.55],[1.5,42.5]]]}"));
        AreaTagImportRegistry reg = new AreaTagImportRegistry(tags, new DefaultImportRegistry());
        assertNotNull(reg.createImportUnit("area_zone"));
        assertNotNull(reg.createImportUnit("car_access"));
        assertNull(reg.createImportUnit("area_other"));
    }

    @Test
    public void invalidPolygonIsRejectedBeforeImport() throws Exception {
        // bow-tie: self-intersecting ring
        try {
            AreaTags.of(collection("bow", "{\"type\":\"Polygon\",\"coordinates\":[[[0,0],[1,1],[1,0],[0,1],[0,0]]]}"));
            fail();
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("invalid geometry"));
        }
    }

    /** Second dataset (Andorra, from GraphHopper's own test files): import with tags, then check every edge. */
    @Test
    public void andorraImportAgreesWithRequestTimeOnEveryEdge() throws Exception {
        String pbf = System.getProperty("andorra.pbf", "gh-src/core/files/andorra.osm.pbf");
        Path dir = Files.createTempDirectory("andorra-gh");
        // Andorra la Vella area, drawn by hand with 9 points
        AreaTags tags = AreaTags.of(collection("vella", "{\"type\":\"Polygon\",\"coordinates\":[[[1.505,42.495],[1.53,42.49],[1.545,42.5],"
                + "[1.55,42.515],[1.54,42.525],[1.52,42.53],[1.505,42.52],[1.5,42.505],[1.505,42.495]]]}"));
        GraphHopper h = new GraphHopper();
        try {
            h.setOSMFile(pbf).setGraphHopperLocation(dir.toString());
            h.setImportRegistry(new AreaTagImportRegistry(tags));
            h.setEncodedValuesString("car_access, car_average_speed, road_access, " + tags.encodedValuesString());
            h.setProfiles(new Profile("car").setCustomModel(GHUtility.loadCustomModelFromJar("car.json")));
            h.importOrLoad();
            AreaTagVerifier.Result r = AreaTagVerifier.verify(h.getBaseGraph(), h.getEncodingManager(), tags, AreaTags.PREFIX);
            assertTrue("edges " + r.edges(), r.edges() > 2000);
            assertTrue("some edges inside", r.areas().get(0).edgesInside() > 300);
            assertEquals(0, r.totalMismatches());
        } finally {
            h.close();
            try (Stream<Path> s = Files.walk(dir)) {
                s.sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
            }
        }
    }

    static JsonFeatureCollection collection(String id, String geometryJson) throws Exception {
        String json = "{\"type\":\"FeatureCollection\",\"features\":[{\"type\":\"Feature\",\"id\":\"" + id
                + "\",\"properties\":{\"area\":\"" + id + "\"},\"geometry\":" + geometryJson + "}]}";
        return com.graphhopper.jackson.Jackson.newObjectMapper().readValue(json, JsonFeatureCollection.class);
    }
}
