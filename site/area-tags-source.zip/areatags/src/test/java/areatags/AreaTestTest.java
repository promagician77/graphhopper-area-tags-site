package areatags;

import com.graphhopper.routing.ev.SimpleBooleanEncodedValue;
import com.graphhopper.routing.util.AreaIndex;
import com.graphhopper.routing.util.CustomArea;
import com.graphhopper.routing.util.EncodingManager;
import com.graphhopper.routing.weighting.custom.CustomWeightingHelper;
import com.graphhopper.storage.BaseGraph;
import com.graphhopper.storage.NodeAccess;
import com.graphhopper.util.EdgeIteratorState;
import com.graphhopper.util.FetchMode;
import com.graphhopper.util.PointList;
import com.graphhopper.util.shapes.Polygon;
import org.junit.Test;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.geom.prep.PreparedPolygon;

import java.util.List;
import java.util.Map;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * The import-time test must give the same answer as GraphHopper's request-time CustomWeightingHelper.in
 * for every edge. These tests build real GraphHopper graphs and compare the two directly.
 */
public class AreaTestTest {
    private static final GeometryFactory GF = new GeometryFactory();

    private static BaseGraph graph() {
        EncodingManager em = EncodingManager.start().add(new SimpleBooleanEncodedValue("dummy")).build();
        return new BaseGraph.Builder(em).create();
    }

    private static Polygon poly(double... lonLat) {
        Coordinate[] c = new Coordinate[lonLat.length / 2 + 1];
        for (int i = 0; i < lonLat.length / 2; i++) c[i] = new Coordinate(lonLat[2 * i], lonLat[2 * i + 1]);
        c[c.length - 1] = c[0];
        return new Polygon(new PreparedPolygon(GF.createPolygon(c)));
    }

    /** Adds an edge a-b with optional bends; returns it. Points are lat,lon pairs. */
    private static EdgeIteratorState edge(BaseGraph g, int a, int b, double[] pa, double[] pb, double... bends) {
        NodeAccess na = g.getNodeAccess();
        na.setNode(a, pa[0], pa[1]);
        na.setNode(b, pb[0], pb[1]);
        EdgeIteratorState e = g.edge(a, b).setDistance(100);
        if (bends.length > 0) {
            PointList pl = new PointList(bends.length / 2, false);
            for (int i = 0; i < bends.length; i += 2) pl.add(bends[i], bends[i + 1]);
            e.setWayGeometry(pl);
        }
        return e;
    }

    private static boolean importTime(Polygon p, EdgeIteratorState e) {
        // what the parser sees during import: the full geometry as doubles
        return AreaTest.in(p, e.fetchWayGeometry(FetchMode.ALL));
    }

    // a 1 x 1 degree square at lon 0..1, lat 50..51
    private final Polygon square = poly(0, 50, 1, 50, 1, 51, 0, 51);
    // same square drawn as a pentagon (extra vertex), so GraphHopper's rectangle shortcut is off
    private final Polygon notRect = poly(0, 50, 0.5, 50, 1, 50, 1, 51, 0, 51);

    @Test
    public void edgeCrossingBoundaryCountsAsInside_likeRequestTime() {
        BaseGraph g = graph();
        // from outside (lon -0.5) to inside (lon 0.1): middle point lon -0.2 is outside
        EdgeIteratorState e = edge(g, 0, 1, new double[]{50.5, -0.5}, new double[]{50.5, 0.1});
        assertTrue(CustomWeightingHelper.in(notRect, e));
        assertTrue(importTime(notRect, e));
    }

    @Test
    public void middlePointShortcutGetsTheCrossingEdgeWrong() {
        // GraphHopper's built-in custom_areas looks up one point per edge (OSMReader.setArtificialWayTags)
        org.locationtech.jts.geom.Polygon jts = GF.createPolygon(new Coordinate[]{
                new Coordinate(0, 50), new Coordinate(1, 50), new Coordinate(1, 51), new Coordinate(0, 51), new Coordinate(0, 50)});
        AreaIndex<CustomArea> index = new AreaIndex<>(List.of(new CustomArea(Map.of("area", "sq"), List.of(jts))));
        double midLat = 50.5, midLon = (-0.5 + 0.1) / 2;
        assertTrue("built-in lookup misses it", index.query(midLat, midLon).isEmpty());
    }

    @Test
    public void bendInsideButEndsOutsideTheBoxIsOutside_likeRequestTime() {
        // GraphHopper's quick reject uses only the two end nodes' box. An edge whose ends are both west of the
        // square but which bends into it is "outside" at request time. The import-time test must agree.
        BaseGraph g = graph();
        EdgeIteratorState e = edge(g, 0, 1, new double[]{50.4, -0.3}, new double[]{50.6, -0.2}, 50.5, 0.4);
        assertFalse(CustomWeightingHelper.in(notRect, e));
        assertFalse(importTime(notRect, e));
    }

    @Test
    public void rectangleShortcutMatches() {
        BaseGraph g = graph();
        EdgeIteratorState inside = edge(g, 0, 1, new double[]{50.2, 0.2}, new double[]{50.8, 0.8});
        EdgeIteratorState outside = edge(g, 2, 3, new double[]{52.2, 0.2}, new double[]{52.8, 0.8});
        assertTrue(square.isRectangle());
        assertEquals(CustomWeightingHelper.in(square, inside), importTime(square, inside));
        assertEquals(CustomWeightingHelper.in(square, outside), importTime(square, outside));
    }

    @Test
    public void touchingTheBoundaryMatchesRequestTime() {
        // An edge that ends exactly on the boundary: GraphHopper's box check decides (here: outside).
        // Whatever request-time says, the tag must say the same.
        BaseGraph g = graph();
        EdgeIteratorState e = edge(g, 0, 1, new double[]{50.5, -0.5}, new double[]{50.5, 0.0});
        EdgeIteratorState f = edge(g, 2, 3, new double[]{50.5, -0.5}, new double[]{50.5, 0.0000001});
        assertEquals(CustomWeightingHelper.in(notRect, e), importTime(notRect, e));
        assertEquals(CustomWeightingHelper.in(notRect, f), importTime(notRect, f));
        assertTrue("one step past the boundary is inside", importTime(notRect, f));
    }

    @Test
    public void storedRoundingIsApplied() {
        // 3e-8 degrees outside the edge: rounds onto the boundary when stored at 1e-7 precision
        BaseGraph g = graph();
        EdgeIteratorState e = edge(g, 0, 1, new double[]{50.5, -0.5}, new double[]{50.5, -0.00000003});
        assertEquals(CustomWeightingHelper.in(notRect, e), AreaTest.in(notRect, e.fetchWayGeometry(FetchMode.ALL)));
        PointList raw = new PointList(2, false);
        raw.add(50.5, -0.5);
        raw.add(50.5, -0.00000003);
        assertEquals("parser input (raw doubles) gives the stored-geometry answer",
                CustomWeightingHelper.in(notRect, e), AreaTest.in(notRect, raw));
    }

    @Test
    public void randomEdgesAndPolygons_allAgree() {
        Random rnd = new Random(11);
        int checked = 0, inside = 0;
        for (int round = 0; round < 40; round++) {
            // random star-shaped polygon (concave), sometimes with a hole
            int n = 5 + rnd.nextInt(60);
            double cx = rnd.nextDouble(), cy = 50 + rnd.nextDouble();
            Coordinate[] c = new Coordinate[n + 1];
            for (int i = 0; i < n; i++) {
                double ang = 2 * Math.PI * i / n, r = 0.05 + rnd.nextDouble() * 0.3;
                c[i] = new Coordinate(cx + r * Math.cos(ang), cy + r * Math.sin(ang));
            }
            c[n] = c[0];
            LinearRing shell = GF.createLinearRing(c);
            LinearRing[] holes = new LinearRing[0];
            if (round % 3 == 0) {
                double hr = 0.02;
                holes = new LinearRing[]{GF.createLinearRing(new Coordinate[]{
                        new Coordinate(cx - hr, cy - hr), new Coordinate(cx + hr, cy - hr), new Coordinate(cx + hr, cy + hr),
                        new Coordinate(cx - hr, cy + hr), new Coordinate(cx - hr, cy - hr)})};
            }
            org.locationtech.jts.geom.Polygon jts = GF.createPolygon(shell, holes);
            if (!jts.isValid()) continue;
            Polygonal geom = round % 4 == 1 ? GF.createMultiPolygon(new org.locationtech.jts.geom.Polygon[]{jts}) : jts;
            Polygon p = new Polygon(new PreparedPolygon(geom));
            BaseGraph g = graph();
            for (int k = 0; k < 500; k++) {
                double lat1 = cy - 0.5 + rnd.nextDouble(), lon1 = cx - 0.5 + rnd.nextDouble();
                double lat2 = lat1 + (rnd.nextDouble() - 0.5) * 0.2, lon2 = lon1 + (rnd.nextDouble() - 0.5) * 0.2;
                int bends = rnd.nextInt(4);
                double[] b = new double[bends * 2];
                for (int i = 0; i < bends; i++) {
                    b[2 * i] = lat1 + (rnd.nextDouble() - 0.5) * 0.2;
                    b[2 * i + 1] = lon1 + (rnd.nextDouble() - 0.5) * 0.2;
                }
                EdgeIteratorState e = edge(g, 2 * k, 2 * k + 1, new double[]{lat1, lon1}, new double[]{lat2, lon2}, b);
                boolean expected = CustomWeightingHelper.in(p, e);
                assertEquals("round " + round + " edge " + k, expected, importTime(p, e));
                checked++;
                if (expected) inside++;
            }
        }
        assertTrue(checked > 15000);
        assertTrue("test must include both answers", inside > 1000 && inside < checked - 1000);
    }
}
