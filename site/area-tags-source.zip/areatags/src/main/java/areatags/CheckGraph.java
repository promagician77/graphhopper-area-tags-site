package areatags;

import com.graphhopper.routing.util.EncodingManager;
import com.graphhopper.storage.BaseGraph;
import com.graphhopper.storage.DAType;
import com.graphhopper.storage.GHDirectory;
import com.graphhopper.storage.StorableProperties;

import java.nio.file.Paths;

/**
 * Command-line check for an imported graph folder (Windows or Linux):
 * <pre>java -cp graphhopper-web-11.0.jar;areatags.jar areatags.CheckGraph graph-cache areas.geojson</pre>
 * (use ':' instead of ';' on Linux). Compares every edge's stored area tag with GraphHopper's
 * request-time polygon test. Exit code 0 when all agree, 1 otherwise. Read-only.
 */
public final class CheckGraph {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("usage: CheckGraph <graph folder> <areas.geojson>");
            System.exit(2);
        }
        AreaTags tags = AreaTags.load(Paths.get(args[1]));
        GHDirectory dir = new GHDirectory(args[0], DAType.RAM_STORE);
        StorableProperties props = new StorableProperties(dir);
        if (!props.loadExisting())
            throw new IllegalStateException("No GraphHopper graph in " + args[0]);
        EncodingManager em = EncodingManager.fromProperties(props);
        for (AreaTags.Area a : tags.areas())
            if (!em.hasEncodedValue(a.encodedValue()))
                throw new IllegalStateException("Graph has no " + a.encodedValue() + "; was it imported with area_tags.file and graph.encoded_values?");
        BaseGraph graph = new BaseGraph.Builder(em).setDir(dir).build();
        if (!graph.loadExisting())
            throw new IllegalStateException("Cannot load graph in " + args[0]);
        AreaTagVerifier.Result r = AreaTagVerifier.verify(graph, em, tags, AreaTags.PREFIX);
        System.out.printf("%d edges checked in %d ms%n", r.edges(), r.millis());
        for (AreaTagVerifier.AreaResult a : r.areas())
            System.out.printf("  %-24s %9d edges inside   %d disagree%s%n", a.encodedValue(), a.edgesInside(), a.mismatches(),
                    a.mismatches() == 0 ? "" : "  first edge ids " + a.mismatchEdges().subList(0, Math.min(10, a.mismatchEdges().size())));
        graph.close();
        System.exit(r.totalMismatches() == 0 ? 0 : 1);
    }
}
