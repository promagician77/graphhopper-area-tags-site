package areatags;

import com.graphhopper.routing.ev.DefaultImportRegistry;
import com.graphhopper.routing.ev.ImportRegistry;
import com.graphhopper.routing.ev.ImportUnit;
import com.graphhopper.routing.ev.SimpleBooleanEncodedValue;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Makes {@code area_<id>} known to GraphHopper as encoded values with their parser; everything else is
 * passed to the default registry. Add the names to {@code graph.encoded_values} so they are stored.
 * <p>
 * {@link #withMiddlePointComparison} also registers {@code mid_<id>} (the built-in custom_areas shortcut),
 * used only by the benchmark to show the difference.
 */
public final class AreaTagImportRegistry implements ImportRegistry {
    private final ImportRegistry fallback;
    private final Map<String, ImportUnit> units = new LinkedHashMap<>();

    public AreaTagImportRegistry(AreaTags tags) {
        this(tags, new DefaultImportRegistry());
    }

    public AreaTagImportRegistry(AreaTags tags, ImportRegistry fallback) {
        this.fallback = fallback;
        for (AreaTags.Area a : tags.areas()) {
            String name = a.encodedValue();
            units.put(name, ImportUnit.create(name,
                    props -> new SimpleBooleanEncodedValue(name, false),
                    (lookup, props) -> new AreaTagParser(lookup.getBooleanEncodedValue(name), a.polygon())));
        }
    }

    public AreaTagImportRegistry withMiddlePointComparison(AreaTags tags) {
        for (AreaTags.Area a : tags.areas()) {
            String name = "mid_" + a.id();
            units.put(name, ImportUnit.create(name,
                    props -> new SimpleBooleanEncodedValue(name, false),
                    (lookup, props) -> new MiddlePointAreaParser(lookup.getBooleanEncodedValue(name), a.id())));
        }
        return this;
    }

    @Override
    public ImportUnit createImportUnit(String name) {
        ImportUnit unit = units.get(name);
        return unit != null ? unit : fallback.createImportUnit(name);
    }
}
