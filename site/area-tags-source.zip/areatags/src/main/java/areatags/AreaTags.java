package areatags;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphhopper.jackson.Jackson;
import com.graphhopper.util.JsonFeature;
import com.graphhopper.util.JsonFeatureCollection;
import com.graphhopper.util.shapes.Polygon;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Polygonal;
import org.locationtech.jts.geom.prep.PreparedPolygon;

import javax.lang.model.SourceVersion;
import java.io.IOException;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The areas to precompute, read once from a GeoJSON FeatureCollection.
 * <p>
 * Each feature's id (for example {@code ulez}) becomes one yes/no encoded value named {@code area_ulez}.
 * Custom models then use {@code "if": "area_ulez"} where requests used {@code "if": "in_ulez"} plus a polygon.
 * The prefix cannot be {@code in_}: GraphHopper 11 rejects encoded value names that start with it
 * (IntEncodedValueImpl.isValidEncodedValue), because {@code in_} is reserved for request-time areas.
 */
public final class AreaTags {
    public static final String PREFIX = "area_";

    public record Area(String id, String encodedValue, Polygon polygon, JsonFeature feature) {
    }

    private final List<Area> areas;

    private AreaTags(List<Area> areas) {
        this.areas = Collections.unmodifiableList(areas);
    }

    public static AreaTags load(Path geoJson) {
        try (Reader reader = Files.newBufferedReader(geoJson, StandardCharsets.UTF_8)) {
            ObjectMapper mapper = Jackson.newObjectMapper();
            return of(mapper.readValue(reader, JsonFeatureCollection.class));
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read area file " + geoJson, e);
        }
    }

    public static AreaTags of(JsonFeatureCollection collection) {
        List<Area> list = new ArrayList<>();
        for (JsonFeature f : collection.getFeatures()) {
            String id = f.getId();
            if (id == null || id.isEmpty())
                throw new IllegalArgumentException("Every area feature needs an id, e.g. \"id\": \"ulez\"");
            String ev = encodedValueName(id);
            Geometry g = f.getGeometry();
            if (!(g instanceof Polygonal))
                throw new IllegalArgumentException("Area " + id + " must be a Polygon or MultiPolygon, was " + (g == null ? "empty" : g.getGeometryType()));
            if (!g.isValid())
                throw new IllegalArgumentException("Area " + id + " has invalid geometry (self-intersection?); fix it before import so results match request-time areas");
            if (list.stream().anyMatch(a -> a.id().equals(id)))
                throw new IllegalArgumentException("Duplicate area id " + id);
            // Same construction as the code GraphHopper generates for request-time areas (CustomModelParser).
            Polygon polygon = new Polygon(new PreparedPolygon((Polygonal) g));
            list.add(new Area(id, ev, polygon, f));
        }
        if (list.isEmpty())
            throw new IllegalArgumentException("The area file has no features");
        return new AreaTags(list);
    }

    /** {@code ulez} becomes {@code area_ulez}; rejects names GraphHopper would not accept as an encoded value. */
    public static String encodedValueName(String id) {
        String name = PREFIX + id;
        if (!id.matches("[a-z][a-z0-9_]*") || id.endsWith("_") || id.contains("__") || SourceVersion.isKeyword(name))
            throw new IllegalArgumentException("Area id '" + id + "' must be lower case letters, digits and single underscores, starting with a letter");
        return name;
    }

    public List<Area> areas() {
        return areas;
    }

    public Area get(String id) {
        return areas.stream().filter(a -> a.id().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown area " + id));
    }

    /** The comma-separated names to append to {@code graph.encoded_values}. */
    public String encodedValuesString() {
        return String.join(", ", areas.stream().map(Area::encodedValue).toList());
    }
}
