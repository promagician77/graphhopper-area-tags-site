package areatags;

import com.graphhopper.routing.ev.BooleanEncodedValue;
import com.graphhopper.routing.ev.EncodedValueLookup;
import com.graphhopper.routing.weighting.custom.CustomWeightingHelper;
import com.graphhopper.storage.BaseGraph;
import com.graphhopper.routing.util.AllEdgesIterator;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * After import: for every stored edge, compare the precomputed tag with GraphHopper's own request-time
 * answer (CustomWeightingHelper.in on the stored geometry). Any difference is listed by edge id.
 * Run it once after each import; it takes seconds and proves the tags will route like the polygons did.
 */
public final class AreaTagVerifier {

    public record AreaResult(String id, String encodedValue, int edgesInside, int mismatches, List<Integer> mismatchEdges) {
    }

    public record Result(int edges, long millis, List<AreaResult> areas) {
        public int totalMismatches() {
            return areas.stream().mapToInt(AreaResult::mismatches).sum();
        }
    }

    /** prefix "area_" checks the exact tags; prefix "mid_" checks the middle-point shortcut. */
    public static Result verify(BaseGraph graph, EncodedValueLookup lookup, AreaTags tags, String prefix) {
        long start = System.nanoTime();
        int n = graph.getEdges();
        List<AreaResult> out = new ArrayList<>();
        for (AreaTags.Area a : tags.areas()) {
            String name = prefix + a.id();
            BooleanEncodedValue enc = lookup.getBooleanEncodedValue(name);
            int inside = 0, bad = 0;
            List<Integer> badEdges = new ArrayList<>();
            AllEdgesIterator it = graph.getAllEdges();
            while (it.next()) {
                boolean stored = it.get(enc);
                boolean requestTime = CustomWeightingHelper.in(a.polygon(), it);
                if (stored) inside++;
                if (stored != requestTime) {
                    bad++;
                    if (badEdges.size() < 5000) badEdges.add(it.getEdge());
                }
            }
            out.add(new AreaResult(a.id(), name, inside, bad, badEdges));
        }
        return new Result(n, (System.nanoTime() - start) / 1_000_000, out);
    }

    public static Map<String, Object> summary(Result r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("edges", r.edges());
        m.put("millis", r.millis());
        m.put("total_mismatches", r.totalMismatches());
        List<Map<String, Object>> list = new ArrayList<>();
        for (AreaResult a : r.areas()) {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("id", a.id());
            x.put("encoded_value", a.encodedValue());
            x.put("edges_inside", a.edgesInside());
            x.put("mismatches", a.mismatches());
            list.add(x);
        }
        m.put("areas", list);
        return m;
    }
}
