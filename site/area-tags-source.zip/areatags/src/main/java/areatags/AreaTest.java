package areatags;

import com.graphhopper.util.Helper;
import com.graphhopper.util.PointList;
import com.graphhopper.util.shapes.BBox;
import com.graphhopper.util.shapes.Polygon;

/**
 * The yes/no test, written to give the same answer as GraphHopper 11's request-time check
 * {@code CustomWeightingHelper.in(Polygon, EdgeIteratorState)}:
 * <ol>
 * <li>quick reject when the polygon's box misses the box of the edge's two end nodes
 * (GHUtility.createBBox uses tower nodes only, not the bends in between);</li>
 * <li>quick accept for rectangles that contain that box;</li>
 * <li>otherwise: does the polygon touch the edge's full geometry anywhere?</li>
 * </ol>
 * At import the parser sees the edge's points as doubles; the graph stores them as integers of
 * 1e-7 degrees. Rounding the same way first means the test runs on the geometry routing will see.
 */
public final class AreaTest {
    private AreaTest() {
    }

    public static boolean in(Polygon polygon, PointList edgePoints) {
        PointList pts = asStored(edgePoints);
        int last = pts.size() - 1;
        BBox edgeBox = BBox.fromPoints(pts.getLat(0), pts.getLon(0), pts.getLat(last), pts.getLon(last));
        BBox polyBox = polygon.getBounds();
        if (!polyBox.intersects(edgeBox))
            return false;
        if (polygon.isRectangle() && polyBox.contains(edgeBox))
            return true;
        return polygon.intersects(pts.makeImmutable());
    }

    /** Copy with every coordinate rounded exactly as BaseGraph stores it. */
    public static PointList asStored(PointList in) {
        PointList out = new PointList(in.size(), false);
        for (int i = 0; i < in.size(); i++)
            out.add(Helper.intToDegree(Helper.degreeToInt(in.getLat(i))), Helper.intToDegree(Helper.degreeToInt(in.getLon(i))));
        return out;
    }
}
