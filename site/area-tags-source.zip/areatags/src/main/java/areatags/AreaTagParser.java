package areatags;

import com.graphhopper.reader.ReaderWay;
import com.graphhopper.routing.ev.BooleanEncodedValue;
import com.graphhopper.routing.ev.EdgeIntAccess;
import com.graphhopper.routing.util.parsers.TagParser;
import com.graphhopper.storage.IntsRef;
import com.graphhopper.util.PointList;
import com.graphhopper.util.shapes.Polygon;

/**
 * Sets one yes/no tag per edge during import.
 * <p>
 * OSMReader.addEdge simplifies the edge geometry first, then puts it on the way as the artificial
 * tag {@code point_list}, then calls the tag parsers, then stores that same geometry. So the parser
 * tests exactly the geometry that routing will later test. Edges added after import (via-way turn
 * restriction copies) copy these flags from their original edge.
 */
public final class AreaTagParser implements TagParser {
    private final BooleanEncodedValue enc;
    private final Polygon polygon;

    public AreaTagParser(BooleanEncodedValue enc, Polygon polygon) {
        this.enc = enc;
        this.polygon = polygon;
    }

    @Override
    public void handleWayTags(int edgeId, EdgeIntAccess edgeIntAccess, ReaderWay way, IntsRef relationFlags) {
        PointList points = way.getTag("point_list", null);
        if (points == null || points.isEmpty())
            throw new IllegalStateException("No point_list on way " + way.getId() + "; AreaTagParser must run inside OSM import");
        enc.setBool(false, edgeId, edgeIntAccess, AreaTest.in(polygon, points));
    }
}
