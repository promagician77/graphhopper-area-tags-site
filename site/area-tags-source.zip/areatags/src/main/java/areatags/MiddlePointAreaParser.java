package areatags;

import com.graphhopper.reader.ReaderWay;
import com.graphhopper.routing.ev.BooleanEncodedValue;
import com.graphhopper.routing.ev.EdgeIntAccess;
import com.graphhopper.routing.util.CustomArea;
import com.graphhopper.routing.util.parsers.TagParser;
import com.graphhopper.storage.IntsRef;

import java.util.Collections;
import java.util.List;

/**
 * For comparison only: the shortcut most people take, using GraphHopper's built-in
 * {@code custom_areas.directory}. OSMReader.setArtificialWayTags looks up ONE point per edge (its middle
 * point, or the midpoint of a straight edge) and attaches the matching areas as {@code custom_areas}.
 * Request-time areas instead test the whole edge, so edges that cross or touch a boundary can disagree.
 * The benchmark counts how often, and whether routes change because of it.
 */
public final class MiddlePointAreaParser implements TagParser {
    private final BooleanEncodedValue enc;
    private final String areaId;

    public MiddlePointAreaParser(BooleanEncodedValue enc, String areaId) {
        this.enc = enc;
        this.areaId = areaId;
    }

    @Override
    public void handleWayTags(int edgeId, EdgeIntAccess edgeIntAccess, ReaderWay way, IntsRef relationFlags) {
        List<CustomArea> found = way.getTag("custom_areas", Collections.emptyList());
        boolean inside = false;
        for (CustomArea a : found)
            if (a.getProperties() != null && areaId.equals(a.getProperties().get("area"))) {
                inside = true;
                break;
            }
        enc.setBool(false, edgeId, edgeIntAccess, inside);
    }
}
