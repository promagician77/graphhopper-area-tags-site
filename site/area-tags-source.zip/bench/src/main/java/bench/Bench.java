package bench;

import areatags.AreaTagImportRegistry;
import areatags.AreaTagVerifier;
import areatags.AreaTags;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.graphhopper.GHRequest;
import com.graphhopper.GHResponse;
import com.graphhopper.GraphHopper;
import com.graphhopper.ResponsePath;
import com.graphhopper.config.LMProfile;
import com.graphhopper.config.Profile;
import com.graphhopper.jackson.Jackson;
import com.graphhopper.json.Statement;
import com.graphhopper.routing.ev.BooleanEncodedValue;
import com.graphhopper.routing.ev.DefaultImportRegistry;
import com.graphhopper.routing.ev.EncodedValueLookup;
import com.graphhopper.util.*;
import com.graphhopper.routing.util.AllEdgesIterator;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.graphhopper.json.Statement.If;
import static com.graphhopper.json.Statement.Op.LIMIT;
import static com.graphhopper.json.Statement.Op.MULTIPLY;

/**
 * Measures the brief's three targets on real data:
 * 1. do routes with precomputed tags equal routes with request-time polygons (every point, distance, time, weight)?
 * 2. how much slower is a tag rule than the same request without area rules (target: at most 1.3x)?
 * 3. does every stored tag agree with GraphHopper's own request-time test, edge by edge?
 * It also runs the built-in custom_areas shortcut (one middle point per edge) to show where it differs.
 *
 * Usage: Bench <osm.pbf> <areas.geojson> <journeys.json> <work dir> <out dir> [reps]
 */
public final class Bench {
    static final ObjectMapper JSON = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    static final String BASE_EVS = "car_access, car_average_speed, road_access";

    public static void main(String[] args) throws Exception {
        Path pbf = Paths.get(args[0]), areasFile = Paths.get(args[1]), journeysFile = Paths.get(args[2]);
        Path work = Paths.get(args[3]), out = Paths.get(args[4]);
        int reps = args.length > 5 ? Integer.parseInt(args[5]) : 15;
        Files.createDirectories(out);
        AreaTags tags = AreaTags.load(areasFile);
        JsonFeatureCollection areaCollection = Jackson.newObjectMapper().readValue(areasFile.toFile(), JsonFeatureCollection.class);
        List<JsonNode> journeys = new ArrayList<>();
        JSON.readTree(journeysFile.toFile()).forEach(journeys::add);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("graphhopper", "11.0 (built from the 11.0 source tag)");
        result.put("java", System.getProperty("java.version"));
        result.put("os", System.getProperty("os.name") + " " + System.getProperty("os.arch"));
        result.put("cpus", Runtime.getRuntime().availableProcessors());
        result.put("osm_file", pbf.getFileName().toString());
        result.put("osm_file_bytes", Files.size(pbf));
        result.put("reps_per_request", reps);

        // ---- Imports: plain, plain + exact tags, and the comparison graph (exact + middle-point + LM)
        Map<String, Object> imports = new LinkedHashMap<>();
        GraphHopper plain = importGraph(pbf, work.resolve("plain"), BASE_EVS, null, false);
        imports.put("plain", importStats(plain, work.resolve("plain")));
        plain.close();

        GraphHopper exact = importGraph(pbf, work.resolve("exact"), BASE_EVS + ", " + tags.encodedValuesString(),
                new AreaTagImportRegistry(tags), false);
        imports.put("with_area_tags", importStats(exact, work.resolve("exact")));
        AreaTagVerifier.Result exactCheck = AreaTagVerifier.verify(exact.getBaseGraph(), exact.getEncodingManager(), tags, AreaTags.PREFIX);
        exact.close();

        Path customAreasDir = Files.createDirectories(work.resolve("custom_areas"));
        Files.copy(areasFile, customAreasDir.resolve("areas.geojson"), StandardCopyOption.REPLACE_EXISTING);
        String midEvs = String.join(", ", tags.areas().stream().map(a -> "mid_" + a.id()).toList());
        GraphHopper hopper = importGraph(pbf, work.resolve("compare"), BASE_EVS + ", " + tags.encodedValuesString() + ", " + midEvs,
                new AreaTagImportRegistry(tags, new DefaultImportRegistry()).withMiddlePointComparison(tags), true,
                customAreasDir.toString());
        imports.put("comparison_graph_with_lm", importStats(hopper, work.resolve("compare")));
        result.put("imports", imports);

        // ---- Edge-by-edge check against GraphHopper's request-time test
        Map<String, Object> checks = new LinkedHashMap<>();
        checks.put("exact_tags_graph", AreaTagVerifier.summary(exactCheck));
        AreaTagVerifier.Result cmpExact = AreaTagVerifier.verify(hopper.getBaseGraph(), hopper.getEncodingManager(), tags, AreaTags.PREFIX);
        AreaTagVerifier.Result cmpMid = AreaTagVerifier.verify(hopper.getBaseGraph(), hopper.getEncodingManager(), tags, "mid_");
        checks.put("exact_tags_comparison_graph", AreaTagVerifier.summary(cmpExact));
        checks.put("middle_point_shortcut", AreaTagVerifier.summary(cmpMid));
        result.put("edge_checks", checks);

        // ---- The rule: same statements, three ways to say "inside the area"
        Function<String, CustomModel> rule = prefix -> ruleWith(prefix, "");
        // Controls: identical statements whose condition ends in "&& false". The area test still runs on every
        // edge the search touches, but no weight changes, so the search is the same as with no area rule.
        // This separates the cost of the area test from the cost of the rule changing the search.
        Function<String, CustomModel> checkOnly = prefix -> ruleWith(prefix, " && false");
        Map<String, CustomModel> variants = new LinkedHashMap<>();
        variants.put("no_area_rule", new CustomModel());
        variants.put("polygons_in_request", rule.apply("in_").setAreas(areaCollection));
        variants.put("precomputed_tags", rule.apply("area_"));
        variants.put("middle_point_shortcut", rule.apply("mid_"));
        variants.put("tag_test_only", checkOnly.apply("area_"));
        variants.put("polygon_test_only", checkOnly.apply("in_").setAreas(areaCollection));
        result.put("rule", Map.of(
                "polygons_in_request", describe(rule.apply("in_")),
                "precomputed_tags", describe(rule.apply("area_")),
                "middle_point_shortcut", describe(rule.apply("mid_"))));
        result.put("request_payload", payloadCost(variants));

        // ---- Routing: flexible mode (no CH, no LM) and LM mode
        Map<String, Object> modes = new LinkedHashMap<>();
        Map<String, Map<String, ResponsePath>> pathsFlexible = new LinkedHashMap<>();
        modes.put("flexible", runMode(hopper, journeys, variants, reps, false, pathsFlexible));
        modes.put("landmarks", runMode(hopper, journeys, variants, reps, true, null));
        result.put("routing", modes);

        Files.writeString(out.resolve("results.json"), JSON.writeValueAsString(result));
        exportForSite(hopper, tags, cmpMid, journeys, pathsFlexible, out.resolve("site-geo.json"));
        hopper.close();
        System.out.println("wrote " + out.resolve("results.json"));
    }

    static CustomModel ruleWith(String prefix, String suffix) {
        return new CustomModel()
                .addToPriority(If(prefix + "aonb" + suffix, MULTIPLY, "0.7"))
                .addToPriority(If(prefix + "newport" + suffix, MULTIPLY, "0.4"))
                .addToPriority(If(prefix + "seaview" + suffix, MULTIPLY, "0.2"))
                .addToSpeed(If(prefix + "ryde" + suffix, LIMIT, "30"));
    }

    static GraphHopper importGraph(Path pbf, Path dir, String evs, AreaTagImportRegistry registry, boolean lm) throws IOException {
        return importGraph(pbf, dir, evs, registry, lm, null);
    }

    static GraphHopper importGraph(Path pbf, Path dir, String evs, AreaTagImportRegistry registry, boolean lm, String customAreasDir) throws IOException {
        deleteDir(dir);
        GraphHopper hopper = new GraphHopper();
        hopper.setOSMFile(pbf.toString());
        hopper.setGraphHopperLocation(dir.toString());
        if (registry != null) hopper.setImportRegistry(registry);
        if (customAreasDir != null) hopper.setCustomAreasDirectory(customAreasDir);
        hopper.setEncodedValuesString(evs);
        hopper.setProfiles(new Profile("car").setCustomModel(GHUtility.loadCustomModelFromJar("car.json")));
        if (lm) hopper.getLMPreparationHandler().setLMProfiles(new LMProfile("car"));
        long t = System.nanoTime();
        hopper.importOrLoad();
        lastImportMillis = (System.nanoTime() - t) / 1_000_000;
        return hopper;
    }

    static long lastImportMillis;

    static Map<String, Object> importStats(GraphHopper h, Path dir) throws IOException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("millis", lastImportMillis);
        m.put("nodes", h.getBaseGraph().getNodes());
        m.put("edges", h.getBaseGraph().getEdges());
        m.put("bytes_for_edge_flags", h.getEncodingManager().getBytesForFlags());
        m.put("encoded_values", h.getEncodingManager().toEncodedValuesAsString());
        try (Stream<Path> s = Files.walk(dir)) {
            m.put("graph_bytes_on_disk", s.filter(Files::isRegularFile).mapToLong(p -> p.toFile().length()).sum());
        }
        return m;
    }

    static List<String> describe(CustomModel cm) {
        List<String> l = new ArrayList<>();
        for (Statement s : cm.getPriority()) l.add("priority: if " + s.condition() + " multiply_by " + s.value());
        for (Statement s : cm.getSpeed()) l.add("speed: if " + s.condition() + " limit_to " + s.value());
        return l;
    }

    /** Size of each request's custom model as JSON, and time to parse it (GraphHopper's own ObjectMapper). */
    static Map<String, Object> payloadCost(Map<String, CustomModel> variants) throws IOException {
        ObjectMapper om = Jackson.newObjectMapper();
        Map<String, Object> m = new LinkedHashMap<>();
        for (Map.Entry<String, CustomModel> e : variants.entrySet()) {
            String body = om.writeValueAsString(e.getValue());
            for (int i = 0; i < 200; i++) om.readValue(body, CustomModel.class);
            long[] ns = new long[200];
            for (int i = 0; i < ns.length; i++) {
                long t = System.nanoTime();
                om.readValue(body, CustomModel.class);
                ns[i] = System.nanoTime() - t;
            }
            Arrays.sort(ns);
            m.put(e.getKey(), Map.of("bytes", body.getBytes().length, "parse_ms_median", round3(ns[ns.length / 2] / 1e6)));
        }
        return m;
    }

    static Map<String, Object> runMode(GraphHopper hopper, List<JsonNode> journeys, Map<String, CustomModel> variants,
                                       int reps, boolean lm, Map<String, Map<String, ResponsePath>> keepPaths) {
        List<String> names = new ArrayList<>(variants.keySet());
        String debugExample = null;
        Random rnd = new Random(42);
        List<Map<String, Object>> rows = new ArrayList<>();
        int exactSame = 0, midDiffers = 0, midPathDiff = 0, ruleChangesRoute = 0;
        Map<String, List<Double>> medians = new LinkedHashMap<>();
        names.forEach(n -> medians.put(n, new ArrayList<>()));
        List<Double> ratioTags = new ArrayList<>(), ratioPolys = new ArrayList<>(), ratioTagTest = new ArrayList<>();

        for (JsonNode j : journeys) {
            Map<String, ResponsePath> paths = new LinkedHashMap<>();
            Map<String, long[]> samples = new LinkedHashMap<>();
            Map<String, Long> visited = new LinkedHashMap<>();
            for (String n : names) samples.put(n, new long[reps]);
            // warm-up: 3 rounds, not timed
            for (int w = 0; w < 3; w++) for (String n : names) route(hopper, j, variants.get(n), lm);
            for (int r = 0; r < reps; r++) {
                List<String> order = new ArrayList<>(names);
                Collections.shuffle(order, rnd);
                for (String n : order) {
                    long t = System.nanoTime();
                    GHResponse rsp = route(hopper, j, variants.get(n), lm);
                    samples.get(n)[r] = System.nanoTime() - t;
                    if (rsp.hasErrors()) throw new IllegalStateException(j.get("id") + " " + n + ": " + rsp.getErrors());
                    if (r == 0) {
                        if (debugExample == null && n.equals("precomputed_tags")) debugExample = rsp.getDebugInfo();
                        paths.put(n, rsp.getBest());
                        visited.put(n, rsp.getHints().getLong("visited_nodes.sum", -1));
                    }
                }
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("id", j.get("id").asText());
            row.put("from", j.get("from").asText());
            row.put("to", j.get("to").asText());
            Map<String, Object> ms = new LinkedHashMap<>();
            for (String n : names) {
                double med = median(samples.get(n)) / 1e6;
                ms.put(n, round3(med));
                medians.get(n).add(med);
            }
            row.put("median_ms", ms);
            double base = (double) ms.get("no_area_rule");
            row.put("tags_vs_no_area", round3((double) ms.get("precomputed_tags") / base));
            row.put("polygons_vs_no_area", round3((double) ms.get("polygons_in_request") / base));
            row.put("tag_test_only_vs_no_area", round3((double) ms.get("tag_test_only") / base));
            row.put("polygon_test_only_vs_no_area", round3((double) ms.get("polygon_test_only") / base));
            ratioTags.add((double) ms.get("precomputed_tags") / base);
            ratioTagTest.add((double) ms.get("tag_test_only") / base);
            ratioPolys.add((double) ms.get("polygons_in_request") / base);

            ResponsePath old = paths.get("polygons_in_request"), tag = paths.get("precomputed_tags"),
                    mid = paths.get("middle_point_shortcut"), none = paths.get("no_area_rule");
            boolean same = identical(old, tag);
            boolean midSame = identical(old, mid);
            boolean midPathDiffers = !samePoints(old.getPoints(), mid.getPoints());
            boolean ruleMatters = !samePoints(none.getPoints(), old.getPoints());
            // the controls must route exactly like no area rule, or they are not controls
            if (!samePoints(none.getPoints(), paths.get("tag_test_only").getPoints())
                    || !samePoints(none.getPoints(), paths.get("polygon_test_only").getPoints()))
                throw new IllegalStateException(j.get("id") + ": control variant changed the route");
            if (same) exactSame++;
            if (!midSame) midDiffers++;
            if (midPathDiffers) midPathDiff++;
            if (ruleMatters) ruleChangesRoute++;
            row.put("tags_route_identical", same);
            row.put("middle_point_route_identical", midSame);
            row.put("middle_point_path_differs", midPathDiffers);
            row.put("middle_point_weight_delta", round3(mid.getRouteWeight() - old.getRouteWeight()));
            row.put("area_rule_changes_route", ruleMatters);
            row.put("km", round3(old.getDistance() / 1000));
            row.put("minutes", round3(old.getTime() / 60000.0));
            row.put("middle_point_km", round3(mid.getDistance() / 1000));
            row.put("middle_point_minutes", round3(mid.getTime() / 60000.0));
            row.put("visited_nodes", visited);
            rows.add(row);
            if (keepPaths != null) keepPaths.put(j.get("id").asText(), paths);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("journeys", journeys.size());
        m.put("debug_example", debugExample);
        m.put("tags_routes_identical", exactSame);
        m.put("middle_point_routes_different", midDiffers);
        m.put("middle_point_paths_different", midPathDiff);
        m.put("area_rule_changes_route", ruleChangesRoute);
        Map<String, Object> agg = new LinkedHashMap<>();
        for (String n : names) {
            List<Double> l = medians.get(n);
            agg.put(n, Map.of("sum_of_medians_ms", round3(l.stream().mapToDouble(d -> d).sum()),
                    "slowest_ms", round3(l.stream().mapToDouble(d -> d).max().orElse(0))));
        }
        m.put("totals", agg);
        double sumBase = medians.get("no_area_rule").stream().mapToDouble(d -> d).sum();
        m.put("tags_vs_no_area_total", round3(medians.get("precomputed_tags").stream().mapToDouble(d -> d).sum() / sumBase));
        m.put("polygons_vs_no_area_total", round3(medians.get("polygons_in_request").stream().mapToDouble(d -> d).sum() / sumBase));
        m.put("tag_test_only_vs_no_area_total", round3(medians.get("tag_test_only").stream().mapToDouble(d -> d).sum() / sumBase));
        m.put("polygon_test_only_vs_no_area_total", round3(medians.get("polygon_test_only").stream().mapToDouble(d -> d).sum() / sumBase));
        m.put("tags_vs_no_area_worst_journey", round3(Collections.max(ratioTags)));
        m.put("polygons_vs_no_area_worst_journey", round3(Collections.max(ratioPolys)));
        m.put("journeys_over_1_3x_with_tags", ratioTags.stream().filter(r -> r > 1.3).count());
        m.put("tag_test_only_worst_journey", round3(Collections.max(ratioTagTest)));
        m.put("per_journey", rows);
        return m;
    }

    static GHResponse route(GraphHopper hopper, JsonNode j, CustomModel cm, boolean lm) {
        GHRequest req = new GHRequest(j.get("from_lat").asDouble(), j.get("from_lon").asDouble(),
                j.get("to_lat").asDouble(), j.get("to_lon").asDouble()).setProfile("car").setCustomModel(cm);
        req.putHint("ch.disable", true);
        req.putHint("lm.disable", !lm);
        return hopper.route(req);
    }

    static boolean identical(ResponsePath a, ResponsePath b) {
        return samePoints(a.getPoints(), b.getPoints()) && a.getDistance() == b.getDistance()
                && a.getTime() == b.getTime() && a.getRouteWeight() == b.getRouteWeight();
    }

    static boolean samePoints(PointList a, PointList b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++)
            if (a.getLat(i) != b.getLat(i) || a.getLon(i) != b.getLon(i)) return false;
        return true;
    }

    static double median(long[] v) {
        long[] c = v.clone();
        Arrays.sort(c);
        return c.length % 2 == 1 ? c[c.length / 2] : (c[c.length / 2 - 1] + c[c.length / 2]) / 2.0;
    }

    static double round3(double d) {
        return Math.round(d * 1000) / 1000.0;
    }

    /** Car-usable edges with their tags, the middle-point disagreements, and the flexible-mode routes. */
    static void exportForSite(GraphHopper h, AreaTags tags, AreaTagVerifier.Result mid, List<JsonNode> journeys,
                              Map<String, Map<String, ResponsePath>> paths, Path file) throws IOException {
        EncodedValueLookup lookup = h.getEncodingManager();
        BooleanEncodedValue access = lookup.getBooleanEncodedValue("car_access");
        List<BooleanEncodedValue> exact = tags.areas().stream().map(a -> lookup.getBooleanEncodedValue(a.encodedValue())).toList();
        Set<Integer> midBad = new HashSet<>();
        Map<Integer, List<String>> midBadAreas = new HashMap<>();
        for (AreaTagVerifier.AreaResult r : mid.areas())
            for (int e : r.mismatchEdges()) {
                midBad.add(e);
                midBadAreas.computeIfAbsent(e, k -> new ArrayList<>()).add(r.id());
            }
        List<Object> edges = new ArrayList<>();
        AllEdgesIterator it = h.getBaseGraph().getAllEdges();
        while (it.next()) {
            if (!it.get(access) && !it.getReverse(access)) continue;
            int mask = 0;
            for (int i = 0; i < exact.size(); i++) if (it.get(exact.get(i))) mask |= 1 << i;
            PointList pl = it.fetchWayGeometry(FetchMode.ALL);
            List<Integer> flat = new ArrayList<>();
            for (int i = 0; i < pl.size(); i++) {
                flat.add((int) Math.round(pl.getLon(i) * 1e5));
                flat.add((int) Math.round(pl.getLat(i) * 1e5));
            }
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("m", mask);
            if (midBad.contains(it.getEdge())) {
                e.put("x", midBadAreas.get(it.getEdge()));
                e.put("n", it.getName());
                e.put("id", it.getEdge());
            }
            e.put("c", flat);
            edges.add(e);
        }
        Map<String, Object> routes = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, ResponsePath>> e : paths.entrySet()) {
            Map<String, Object> v = new LinkedHashMap<>();
            for (Map.Entry<String, ResponsePath> p : e.getValue().entrySet()) {
                PointList pl = p.getValue().getPoints();
                List<Integer> flat = new ArrayList<>();
                for (int i = 0; i < pl.size(); i++) {
                    flat.add((int) Math.round(pl.getLon(i) * 1e5));
                    flat.add((int) Math.round(pl.getLat(i) * 1e5));
                }
                v.put(p.getKey(), Map.of("c", flat, "km", round3(p.getValue().getDistance() / 1000),
                        "min", round3(p.getValue().getTime() / 60000.0)));
            }
            routes.put(e.getKey(), v);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("area_order", tags.areas().stream().map(AreaTags.Area::id).toList());
        m.put("edges", edges);
        m.put("routes", routes);
        new ObjectMapper().writeValue(file.toFile(), m);
    }

    static void deleteDir(Path dir) throws IOException {
        if (!Files.exists(dir)) return;
        try (Stream<Path> s = Files.walk(dir)) {
            s.sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
        }
    }
}
