package bench;

import areatags.AreaTagImportRegistry;
import areatags.AreaTags;
import com.graphhopper.GraphHopper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/** Import time with and without the four area tags: one warm-up each, then 4 alternating rounds; reports the median. */
public final class ImportTiming {
    public static void main(String[] a) throws Exception {
        Path pbf = Paths.get(a[0]), areas = Paths.get(a[1]), work = Paths.get(a[2]);
        AreaTags tags = AreaTags.load(areas);
        List<Long> plain = new ArrayList<>(), tagged = new ArrayList<>();
        for (int round = 0; round < 5; round++) {
            GraphHopper p = Bench.importGraph(pbf, work.resolve("t-plain"), Bench.BASE_EVS, null, false);
            long pm = Bench.lastImportMillis;
            p.close();
            GraphHopper t = Bench.importGraph(pbf, work.resolve("t-tags"), Bench.BASE_EVS + ", " + tags.encodedValuesString(), new AreaTagImportRegistry(tags), false);
            long tm = Bench.lastImportMillis;
            t.close();
            if (round > 0) { plain.add(pm); tagged.add(tm); }
        }
        Collections.sort(plain);
        Collections.sort(tagged);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("plain_ms_runs", plain);
        m.put("with_tags_ms_runs", tagged);
        double mp = (plain.get(1) + plain.get(2)) / 2.0, mt = (tagged.get(1) + tagged.get(2)) / 2.0;
        m.put("plain_ms_median", mp);
        m.put("with_tags_ms_median", mt);
        m.put("added_ms", mt - mp);
        Files.writeString(Paths.get(a[3]), Bench.JSON.writeValueAsString(m));
        System.out.println(m);
    }
}
