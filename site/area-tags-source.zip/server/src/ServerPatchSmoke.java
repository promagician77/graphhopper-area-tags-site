import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.graphhopper.GHRequest;
import com.graphhopper.GHResponse;
import com.graphhopper.GraphHopper;
import com.graphhopper.GraphHopperConfig;
import com.graphhopper.config.Profile;
import com.graphhopper.http.GraphHopperManaged;
import com.graphhopper.jackson.Jackson;
import com.graphhopper.util.GHUtility;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Starts GraphHopper through the patched GraphHopperManaged (as the web server does, without the HTTP layer),
 * then sends the same journey as two POST /route bodies: the old one carrying polygons, the new one using tags.
 * Usage: ServerPatchSmoke <osm.pbf> <areas.geojson> <graph dir> <examples out dir>
 */
public class ServerPatchSmoke {
    public static void main(String[] a) throws Exception {
        GraphHopperConfig cfg = new GraphHopperConfig();
        cfg.putObject("datareader.file", a[0]);
        cfg.putObject("graph.location", a[2]);
        cfg.putObject("area_tags.file", a[1]);
        cfg.putObject("import.osm.ignored_highways", ""); // same graph as the benchmark
        cfg.putObject("graph.encoded_values", "car_access, car_average_speed, road_access, area_newport, area_ryde, area_aonb, area_seaview");
        cfg.setProfiles(List.of(new Profile("car").setCustomModel(GHUtility.loadCustomModelFromJar("car.json"))));
        GraphHopperManaged managed = new GraphHopperManaged(cfg);
        managed.start();
        GraphHopper gh = managed.getGraphHopper();

        ObjectMapper om = Jackson.newObjectMapper();
        Path out = Files.createDirectories(Paths.get(a[3]));
        // Ryde -> Easton (J27), crosses Newport, Ryde and the AONB
        String common = "\"points\":[[-1.16037,50.72999],[-1.51522,50.6749]],\"profile\":\"car\",\"ch.disable\":true,";
        String rule = "\"priority\":[{\"if\":\"%1$saonb\",\"multiply_by\":\"0.7\"},{\"if\":\"%1$snewport\",\"multiply_by\":\"0.4\"},"
                + "{\"if\":\"%1$sseaview\",\"multiply_by\":\"0.2\"}],\"speed\":[{\"if\":\"%1$sryde\",\"limit_to\":\"30\"}]";
        String areas = Files.readString(Paths.get(a[1]));
        String oldBody = "{" + common + "\"custom_model\":{" + String.format(rule, "in_") + ",\"areas\":" + areas + "}}";
        String newBody = "{" + common + "\"custom_model\":{" + String.format(rule, "area_") + "}}";
        Files.writeString(out.resolve("request-before-polygons.json"), oldBody);
        ObjectNode pretty = (ObjectNode) om.readTree(newBody);
        Files.writeString(out.resolve("request-after-tags.json"), newBody);
        Files.writeString(out.resolve("request-after-tags.pretty.json"), om.writerWithDefaultPrettyPrinter().writeValueAsString(pretty));

        GHResponse oldR = gh.route(om.readValue(oldBody, GHRequest.class));
        GHResponse newR = gh.route(om.readValue(newBody, GHRequest.class));
        if (oldR.hasErrors() || newR.hasErrors())
            throw new IllegalStateException(oldR.getErrors() + " " + newR.getErrors());
        boolean same = oldR.getBest().getPoints().toString().equals(newR.getBest().getPoints().toString())
                && oldR.getBest().getDistance() == newR.getBest().getDistance()
                && oldR.getBest().getTime() == newR.getBest().getTime();
        System.out.printf("before: %d bytes, %.2f km, %.1f min%n", oldBody.length(), oldR.getBest().getDistance() / 1000, oldR.getBest().getTime() / 60000.0);
        System.out.printf("after:  %d bytes, %.2f km, %.1f min%n", newBody.length(), newR.getBest().getDistance() / 1000, newR.getBest().getTime() / 60000.0);
        System.out.println("identical route: " + same);
        java.util.Map<String, Object> r = new java.util.LinkedHashMap<>();
        r.put("journey", "Ryde -> Easton");
        r.put("before_body_bytes", oldBody.getBytes().length);
        r.put("after_body_bytes", newBody.getBytes().length);
        r.put("km", Math.round(newR.getBest().getDistance()) / 1000.0);
        r.put("minutes", Math.round(newR.getBest().getTime() / 6000.0) / 10.0);
        r.put("identical_route", same);
        Files.writeString(out.resolve("smoke-result.json"), om.writerWithDefaultPrettyPrinter().writeValueAsString(r));
        managed.stop();
        if (!same) System.exit(1);
    }
}
