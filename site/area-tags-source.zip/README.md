# Area tags at import for GraphHopper 11.0

Four yes/no tags per road, worked out once at import and used in custom-model conditions
(`area_newport` instead of `in_newport` plus a polygon). Tested on GraphHopper 11.0, built from its source tag,
with the Isle of Wight OSM extract, four real OSM boundaries and 27 test journeys.

## Results (measured)

| | Flexible mode | Landmarks |
|---|---|---|
| Routes identical to polygons in the request (points, distance, time, weight) | 27 of 27 | 27 of 27 |
| Routing time, sum of 27 per-journey medians (25 runs each): polygons | 817 ms | 806 ms |
| Same, area tags | 80 ms | 89 ms |
| Same, no area rule | 51 ms | 56 ms |
| Tags ÷ no area rule (rule active) | 1.56×, 18 of 27 journeys above 1.3× | 1.58×, 18 of 27 above 1.3× |
| Tag test only ÷ no area rule (statements kept, `&& false`) | 1.13×, worst journey 1.27× | 1.13×, worst journey 1.17× |
| Roads visited: no area rule / with the area rule | 81,302 / 123,302 (1.52×) | |
| Cost per road visited: no rule / tags / polygons | 0.63 / 0.65 / 6.62 µs | |

| Check | Result |
|---|---|
| Stored tag vs GraphHopper's request-time test (`CustomWeightingHelper.in`), every edge × 4 areas | 0 of 202,292 disagree |
| GraphHopper's built-in `custom_areas` lookup (one middle point per edge), same check | 801 disagree (475 car roads); 5 journeys get another time or distance, 2 another path (J10, J22) |
| POST /route body for one journey (Ryde → Easton) | 271,950 bytes with polygons, 283 with tags; identical route |
| Parsing the custom model JSON (GraphHopper's mapper) | 3.299 ms with polygons, 0.004 ms with tags |
| Graph size | edge flags 7 bytes before and after; +1,414 bytes on disk |
| Import time (median of 4 alternating runs) | 0.90 s without tags, 0.89 s with (within noise) |
| GraphHopper 11.0's own core + web-api tests on this build | 2,574 passed, 0 failed, 16 skipped upstream, 2 stopped by their own assumptions |
| Plugin tests | 12 passed |

The rule used: priority ×0.7 in the AONB, ×0.4 in Newport, ×0.2 in Nettlestone and Seaview, speed limit 30 km/h in Ryde,
on GraphHopper's built-in `car.json`. It changes the route on 14 of 27 journeys, so a wrong tag would show.

### Measured vs not measured

Measured here: everything in the tables above, on a 2-core Linux sandbox, Java 21.0.12.1.

Not measured:
- Your UK graph: timings at that size and the 5-second target.
- Your four boundaries, your 27 journeys and your timing script.
- Windows. The code is plain Java with no native parts, but it was only run on Linux.
- A Maven build. `areatags/pom.xml` is written but Maven Central was blocked in the sandbox (see Build notes).
- CH profiles with tag rules (possible, since the tags are ordinary encoded values; not tested).
- The HTTP layer of the web server. The patched `GraphHopperManaged` was run with Dropwizard's `Managed` interface stubbed, fed real POST /route JSON bodies.

## How it works

| Class | Job |
|---|---|
| `AreaTags` | Reads the area GeoJSON once; feature `ulez` becomes encoded value `area_ulez`. Rejects bad names and invalid polygons. |
| `AreaTest` | The yes/no test, matching `CustomWeightingHelper.in`: quick reject on the box of the edge's two end nodes, rectangle shortcut, then "does the polygon touch the edge's full geometry", on coordinates rounded as the graph stores them. |
| `AreaTagParser` | Runs for every edge during import. OSMReader simplifies the geometry, puts it on the way as `point_list`, calls the parsers, then stores that geometry, so the parser tests what routing will test. |
| `AreaTagImportRegistry` | Registers `area_*` as yes/no encoded values with that parser; everything else goes to GraphHopper's default registry. |
| `AreaTagVerifier` / `CheckGraph` | After import, compares every stored tag with GraphHopper's request-time answer. `CheckGraph` is the command-line version (exit code 1 on any difference). |
| `MiddlePointAreaParser` | For comparison only: the built-in `custom_areas` shortcut. |

Encoded value names may not start with `in_` in GraphHopper 11 (`IntEncodedValueImpl.isValidEncodedValue`), hence `area_`.
Changing an area means re-importing, because the answer is stored in the graph.

## Use it with a GraphHopper 11.0 server (Linux or Windows; written, not run here)

1. Check out GraphHopper at tag `11.0` and copy `areatags/src/main/java/areatags` into `web-bundle/src/main/java/`.
2. `git apply server/patch/graphhopper-11.0-area-tags.patch` (five lines in `GraphHopperManaged`; applies cleanly to 11.0).
3. `mvn -DskipTests clean package` (same command in PowerShell).
4. In `config.yml`: `area_tags.file: areas.geojson` and add `area_<id>` for each area to `graph.encoded_values`.
5. Import as usual: `java -jar web/target/graphhopper-web-11.0.jar import config.yml`.
6. Check every edge: `java -cp web/target/graphhopper-web-11.0.jar areatags.CheckGraph graph-cache areas.geojson`.
7. In requests, use `area_<id>` where you used `in_<id>`, and drop `areas`. Example: `server/examples/request-after-tags.pretty.json`.

Area file: a GeoJSON FeatureCollection; each feature has an `id` (lower-case letters, digits, single underscores) and a valid Polygon or MultiPolygon.

## Reproduce the measurements (Linux)

```
scripts/build.sh               # plugin + benchmark against lib/graphhopper-core-11.0-offline.jar
scripts/test.sh                # 12 plugin tests (JUnit 4)
scripts/test-graphhopper.sh    # GraphHopper's own test suites on this build
scripts/server-smoke.sh        # patched GraphHopperManaged + real request JSON
source scripts/env.sh && java -Xmx3g -cp "$CP:lib/areatags.jar:lib/bench.jar" bench.Bench \
  data/iow.osm.pbf data/areas/areas.geojson data/journeys.json /tmp/ghwork out 25
python3 tools/site_data.py . site/data/map.json && (cd site && npm install && node build.mjs)
```

Inputs: `data/iow.osm.pbf` (Geofabrik Isle of Wight extract, OSM data of 2020-07-21, sha256 b9a73879ae90427b…),
`data/areas/areas.geojson` (four OSM boundary relations: Newport, Ryde, Nettlestone and Seaview, Isle of Wight AONB),
`data/journeys.json` (27 journeys between OSM town and village nodes, picked by `tools/make_journeys.py` with a fixed seed).

## Build notes

The sandbox could reach GitHub and Ubuntu's package archive but not Maven Central, so:
- GraphHopper 11.0 was compiled with javac from the `11.0` git tag (commit 69e50f6) against Ubuntu's jars:
  Jackson 2.14, JTS 1.19, HPPC 0.7.2 (upstream uses 0.8.1), protobuf 3.21, SLF4J 1.7.
- Janino 3.1.9 and jackson-datatype-jts were compiled from their git sources; the OSM PBF classes were generated with protoc
  from the OSM-binary `.proto` files under Osmosis's package name.
- `MaxSpeedCalculator` (needs a Kotlin library) is replaced by a stub that throws if used; it is only used when
  `max_speed_calculator.enabled` is set, which this project never does.
- With that build, GraphHopper's own test suites give 2,574 passed and 0 failed (`out/graphhopper-tests.txt`).

## Data and licences

Map data © OpenStreetMap contributors, ODbL 1.0; extract by Geofabrik. GraphHopper is Apache 2.0.
