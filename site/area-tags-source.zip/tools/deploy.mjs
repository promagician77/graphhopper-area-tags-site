// Makes deploy/: the prebuilt static site plus vercel.json (noindex on every response), package.json and a short README.
import { cpSync, rmSync, mkdirSync, writeFileSync } from 'node:fs';
const vercel = {
  $schema: 'https://openapi.vercel.sh/vercel.json',
  framework: null,
  installCommand: "echo 'prebuilt static site: nothing to install'",
  buildCommand: "echo 'prebuilt static site: site/ is committed'",
  outputDirectory: 'site',
  cleanUrls: true,
  headers: [
    { source: '/(.*)', headers: [
      { key: 'X-Robots-Tag', value: 'noindex, nofollow' },
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'X-Frame-Options', value: 'DENY' },
    ] },
    { source: '/fonts/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    { source: '/area-tags-source.zip', headers: [{ key: 'Content-Disposition', value: 'attachment' }] },
  ],
};
rmSync('deploy', { recursive: true, force: true });
mkdirSync('deploy', { recursive: true });
cpSync('site/dist', 'deploy/site', { recursive: true });
writeFileSync('deploy/site/robots.txt', 'User-agent: *\nDisallow: /\n');
writeFileSync('deploy/vercel.json', JSON.stringify(vercel, null, 2));
writeFileSync('deploy/package.json', JSON.stringify({ name: 'graphhopper-area-tags-demo', private: true, version: '1.0.0',
  description: 'GraphHopper 11 area tags at import: prebuilt static site in site/.',
  scripts: { build: "echo 'prebuilt: site/ is committed'", start: 'npx --yes serve site' } }, null, 2));
writeFileSync('deploy/README.md', `# GraphHopper area tags demo (prebuilt)

Static site in \`site/\`. Deploy this folder as a Vercel project:

\`\`\`
cd deploy
npx vercel deploy --prod
\`\`\`

Or import it in Vercel with **Root Directory** set to this folder. No build step runs.
\`vercel.json\` sends \`X-Robots-Tag: noindex, nofollow\` on every response, and \`robots.txt\` disallows all crawling.

The plugin source, scripts and raw results are in \`site/area-tags-source.zip\`. The full README, including what was and
was not measured, is at the root of the project zip.
`);
console.log('deploy/ ready');
