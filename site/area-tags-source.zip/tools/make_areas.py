"""Writes the four test boundaries (real OSM polygons from the Isle of Wight extract) as one GeoJSON
FeatureCollection that works three ways: as request-time `areas` (feature id), as the file the
import-time tagger reads, and as GraphHopper's built-in custom_areas.directory (property `area`)."""
import json, sys
from shapely import wkt
from shapely.geometry import mapping
src = json.load(open(sys.argv[1]))
pick = {  # id -> OSM name
    'newport': 'Newport',
    'ryde': 'Ryde',
    'aonb': 'Isle of Wight AONB',
    'seaview': 'Nettlestone and Seaview',
}
feats = []
for fid, name in pick.items():
    a = next(a for a in src['areas'] if a['name'] == name)
    g = wkt.loads(a['wkt'])
    if g.geom_type == 'MultiPolygon' and len(g.geoms) == 1:
        g = g.geoms[0]
    def r(c):
        return [round(c[0], 7), round(c[1], 7)]
    gm = mapping(g)
    if gm['type'] == 'Polygon':
        coords = [[r(c) for c in ring] for ring in gm['coordinates']]
    else:
        coords = [[[r(c) for c in ring] for ring in poly] for poly in gm['coordinates']]
    feats.append({'type': 'Feature', 'id': fid,
                  'properties': {'area': fid, 'name': name, 'osm_id': a['id'], 'osm_type': 'relation' if a['rel'] else 'way',
                                 'vertices': a['verts'], 'parts': a['parts'], 'area_km2': a['area_km2']},
                  'geometry': {'type': gm['type'], 'coordinates': coords}})
    print(fid, name, gm['type'], a['verts'], 'verts', a['parts'], 'parts', a['area_km2'], 'km2')
json.dump({'type': 'FeatureCollection', 'features': feats}, open(sys.argv[2], 'w'))
