"""Picks 27 test journeys between real Isle of Wight towns and villages (OSM place nodes).
Deterministic: same input, same 27 journeys. Mix of short, cross-island and through-Newport trips."""
import json, math, random, sys
from shapely.geometry import shape, LineString
places = [p for p in json.load(open(sys.argv[1]))['places'] if p['place'] in ('town', 'village')]
areas = {f['id']: shape(f['geometry']) for f in json.load(open(sys.argv[2]))['features']}
def km(a, b):
    dy = (a['lat'] - b['lat']) * 111.2
    dx = (a['lon'] - b['lon']) * 111.2 * math.cos(math.radians(50.7))
    return math.hypot(dx, dy)
rng = random.Random(11)  # GraphHopper 11
cands = [(a, b) for i, a in enumerate(places) for b in places[i + 1:] if 4 <= km(a, b) <= 32]
rng.shuffle(cands)
picked, seen_ends = [], {}
buckets = {'short': (4, 10, 8), 'medium': (10, 18, 10), 'long': (18, 32, 9)}
count = {k: 0 for k in buckets}
for a, b in cands:
    d = km(a, b)
    band = next(k for k, (lo, hi, n) in buckets.items() if lo <= d < hi or (k == 'long' and d == hi))
    if count[band] >= buckets[band][2]:
        continue
    if seen_ends.get(a['name'], 0) >= 2 or seen_ends.get(b['name'], 0) >= 2:
        continue
    line = LineString([(a['lon'], a['lat']), (b['lon'], b['lat'])])
    crosses = [k for k, g in areas.items() if line.intersects(g)]
    picked.append({'id': f'J{len(picked) + 1:02d}', 'from': a['name'], 'to': b['name'],
                   'from_lat': a['lat'], 'from_lon': a['lon'], 'to_lat': b['lat'], 'to_lon': b['lon'],
                   'straight_km': round(d, 1), 'band': band, 'line_crosses': crosses})
    count[band] += 1
    seen_ends[a['name']] = seen_ends.get(a['name'], 0) + 1
    seen_ends[b['name']] = seen_ends.get(b['name'], 0) + 1
    if len(picked) == 27:
        break
picked.sort(key=lambda j: j['straight_km'])
for i, j in enumerate(picked):
    j['id'] = f'J{i + 1:02d}'
    print(j['id'], j['from'], '->', j['to'], j['straight_km'], 'km', j['band'], j['line_crosses'])
json.dump(picked, open(sys.argv[3], 'w'), indent=1)
