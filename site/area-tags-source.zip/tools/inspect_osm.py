import sys, json, osmium
from shapely import wkb
pbf = sys.argv[1]
fab = osmium.geom.WKBFactory()
class H(osmium.SimpleHandler):
    def __init__(s):
        super().__init__(); s.areas=[]; s.places=[]
    def node(s, n):
        p = n.tags.get('place')
        if p in ('town','village','city','suburb','hamlet') and n.tags.get('name'):
            s.places.append(dict(name=n.tags['name'], place=p, lat=n.location.lat, lon=n.location.lon))
    def area(s, a):
        t = a.tags
        if t.get('boundary') in ('administrative','low_emission_zone','protected_area','national_park') or t.get('landuse') in ('residential',) and t.get('name'):
            if t.get('boundary') is None and t.get('landuse') == 'residential' and not t.get('name'): return
            try:
                g = wkb.loads(fab.create_multipolygon(a), hex=True)
            except Exception:
                return
            s.areas.append(dict(id=a.orig_id(), rel=not a.from_way(), name=t.get('name'), boundary=t.get('boundary'), landuse=t.get('landuse'),
                                admin_level=t.get('admin_level'), area_km2=round(g.area*111.0*111.0*0.633,2), verts=len(g.exterior.coords) if g.geom_type=='Polygon' else sum(len(p.exterior.coords) for p in g.geoms), parts=1 if g.geom_type=='Polygon' else len(g.geoms), wkt=g.wkt))
h = H(); h.apply_file(pbf, locations=True)
r = osmium.io.Reader(pbf); hd = r.header(); print('header timestamp', hd.get('osmosis_replication_timestamp'), 'box', hd.box()); r.close()
print('places', len(h.places))
for p in sorted(h.places, key=lambda x:(x['place'],x['name'])):
    if p['place'] in ('town','city','village'): print(' ', p['place'], p['name'], round(p['lat'],5), round(p['lon'],5))
print('areas', len(h.areas))
for a in sorted(h.areas, key=lambda x:(str(x['boundary']),str(x['admin_level']),-x['area_km2'])):
    if a['boundary']: print(' ', a['boundary'], a['admin_level'], a['name'], a['area_km2'],'km2', a['verts'],'verts', a['parts'],'parts')
json.dump(dict(places=h.places, areas=[a for a in h.areas if a['boundary']]), open(sys.argv[2],'w'))
