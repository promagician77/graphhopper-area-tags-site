"""Builds the site's data file from the benchmark outputs (results.json, site-geo.json) and the OSM extract
inspection. Coordinates are integers of 1e-5 degrees, delta-encoded per line."""
import json, sys
from shapely import wkt
from shapely.geometry import mapping, shape
root = sys.argv[1]
res = json.load(open(f'{root}/out/results.json'))
geo = json.load(open(f'{root}/out/site-geo.json'))
imp = json.load(open(f'{root}/out/import-timing.json'))
osm = json.load(open(f'{root}/data/osm_inspect.json'))
areas = json.load(open(f'{root}/data/areas/areas.geojson'))
journeys = json.load(open(f'{root}/data/journeys.json'))

def delta(flat):
    out, px, py = [], 0, 0
    for i in range(0, len(flat), 2):
        x, y = flat[i], flat[i + 1]
        out += [x - px, y - py]; px, py = x, y
    return out

def rings(geom, tol):
    g = geom.simplify(tol, preserve_topology=True)
    polys = [g] if g.geom_type == 'Polygon' else list(g.geoms)
    out = []
    for p in polys:
        for r in [p.exterior] + list(p.interiors):
            out.append(delta([v for c in r.coords for v in (round(c[0] * 1e5), round(c[1] * 1e5))]))
    return out

land = wkt.loads(next(a for a in osm['areas'] if a['admin_level'] == '6')['wkt'])
order = geo['area_order']
data = {
    'land': rings(land, 0.0004),
    'areas': [{'id': f['id'], 'name': f['properties']['name'], 'vertices': f['properties']['vertices'],
               'parts': f['properties']['parts'], 'km2': f['properties']['area_km2'],
               'rings': rings(shape(f['geometry']), 0.00008)} for f in areas['features']],
    'area_order': order,
    'roads': [], 'wrong': [],
}
for e in geo['edges']:
    if 'x' in e:
        data['wrong'].append({'areas': e['x'], 'name': e.get('n') or '', 'edge': e['id'], 'c': delta(e['c'])})
    data['roads'].append([e['m']] + delta(e['c']))
flex = {j['id']: j for j in res['routing']['flexible']['per_journey']}
lm = {j['id']: j for j in res['routing']['landmarks']['per_journey']}
data['journeys'] = []
for j in journeys:
    r = geo['routes'][j['id']]
    f = flex[j['id']]
    item = {'id': j['id'], 'from': j['from'], 'to': j['to'], 'straight_km': j['straight_km'],
            'tags': {'c': delta(r['precomputed_tags']['c']), 'km': r['precomputed_tags']['km'], 'min': r['precomputed_tags']['min']},
            'identical': f['tags_route_identical'], 'rule_changes_route': f['area_rule_changes_route'],
            'ms': f['median_ms'], 'ms_lm': lm[j['id']]['median_ms'], 'visited': f['visited_nodes'],
            'mid_path_differs': f['middle_point_path_differs'], 'mid_km': f['middle_point_km'], 'mid_min': f['middle_point_minutes']}
    if f['middle_point_path_differs'] or r['middle_point_shortcut']['km'] != r['precomputed_tags']['km'] or r['middle_point_shortcut']['min'] != r['precomputed_tags']['min']:
        item['mid'] = {'c': delta(r['middle_point_shortcut']['c']), 'km': r['middle_point_shortcut']['km'], 'min': r['middle_point_shortcut']['min']}
    if f['area_rule_changes_route']:
        item['none'] = {'c': delta(r['no_area_rule']['c']), 'km': r['no_area_rule']['km'], 'min': r['no_area_rule']['min']}
    data['journeys'].append(item)
s = {k: v for k, v in res.items() if k not in ('routing',)}
s['routing'] = {m: {k: v for k, v in res['routing'][m].items() if k != 'per_journey'} for m in res['routing']}
s['import_timing'] = imp
data['summary'] = s
data['towns'] = [{'name': p['name'], 'x': round(p['lon'] * 1e5), 'y': round(p['lat'] * 1e5)}
                 for p in osm['places'] if p['place'] in ('town', 'city')]
json.dump(data, open(sys.argv[2], 'w'), separators=(',', ':'))
print('roads', len(data['roads']), 'wrong', len(data['wrong']), 'journeys', len(data['journeys']))
