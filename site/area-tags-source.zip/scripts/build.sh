#!/usr/bin/env bash
# Compiles the area-tag plugin and the benchmark against GraphHopper 11.0.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$ROOT"
rm -rf build/areatags build/bench && mkdir -p build/areatags build/bench
javac -nowarn -encoding UTF-8 --release 17 -cp "$CP" -d build/areatags $(find areatags/src/main/java -name '*.java')
(cd build/areatags && jar cf "$ROOT/lib/areatags.jar" .)
javac -nowarn -encoding UTF-8 --release 17 -cp "$CP:lib/areatags.jar" -d build/bench $(find bench/src/main/java -name '*.java')
(cd build/bench && jar cf "$ROOT/lib/bench.jar" .)
echo "built lib/areatags.jar lib/bench.jar"
