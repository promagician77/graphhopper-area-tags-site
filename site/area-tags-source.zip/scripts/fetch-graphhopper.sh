#!/usr/bin/env bash
# GraphHopper 11.0 source (tests, test files, the web server class the patch changes). Not shipped in the zip.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[ -d "$ROOT/gh-src" ] || git clone -q --depth 1 --branch 11.0 https://github.com/graphhopper/graphhopper.git "$ROOT/gh-src"
