#!/usr/bin/env bash
# Rebuilds lib/graphhopper-core-11.0-offline.jar (and its helper jars) without Maven Central:
# GraphHopper 11.0 from its git tag, Janino 3.1.9 and jackson-datatype-jts from git, OSM PBF classes via protoc,
# everything else from Ubuntu packages. This is how the jars in lib/ were made. Needs: git, javac 17+, apt (root).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export JAVA_TOOL_OPTIONS=

apt-get install -y -q libjts-java libjackson2-core-java libjackson2-databind-java libjackson2-annotations-java \
  libjackson2-dataformat-xml-java libxmlgraphics-commons-java libcarrotsearch-hppc-java libprotobuf-java libslf4j-java \
  protobuf-compiler junit4 libhamcrest-java junit5 >/dev/null

[ -d gh-src ] || git clone -q --depth 1 --branch 11.0 https://github.com/graphhopper/graphhopper.git gh-src
mkdir -p deps lib build
[ -d deps/janino ] || git clone -q --depth 1 --branch v3.1.9 https://github.com/janino-compiler/janino.git deps/janino
[ -d deps/jackson-datatype-jts ] || git clone -q --depth 1 https://github.com/graphhopper/jackson-datatype-jts.git deps/jackson-datatype-jts
J=/usr/share/java

# Janino 3.1.9 (without the Ant adapter, which needs Ant)
rm -rf build/janino && mkdir -p build/janino
find deps/janino/commons-compiler/src/main/java deps/janino/janino/src/main/java -name '*.java' | xargs grep -L 'org.apache.tools.ant' > build/janino-src.txt
javac -nowarn -encoding UTF-8 --release 17 -d build/janino @build/janino-src.txt
for d in deps/janino/commons-compiler/src/main/resources deps/janino/janino/src/main/resources; do [ -d "$d" ] && cp -r "$d/." build/janino/; done
(cd build/janino && jar cf "$ROOT/lib/janino-3.1.9-src.jar" .)

# jackson-datatype-jts
rm -rf build/djts && mkdir -p build/djts
javac -nowarn -encoding UTF-8 --release 17 -cp "$J/jackson-core.jar:$J/jackson-databind.jar:$J/jackson-annotations.jar:$J/jts-core.jar" \
  -d build/djts $(find deps/jackson-datatype-jts/src/main/java -name '*.java')
(cd build/djts && jar cf "$ROOT/lib/jackson-datatype-jts-src.jar" .)

# OSM PBF protobuf classes under Osmosis's package name (what GraphHopper imports)
mkdir -p deps/proto/gen build/osmbin
for f in fileformat osmformat; do
  [ -f deps/proto/$f.proto ] || curl -s -o deps/proto/$f.proto https://raw.githubusercontent.com/openstreetmap/OSM-binary/master/osmpbf/$f.proto
done
sed -i 's/option java_package = "crosby.binary";/option java_package = "org.openstreetmap.osmosis.osmbinary";/' deps/proto/*.proto
protoc --java_out=deps/proto/gen --proto_path=deps/proto deps/proto/fileformat.proto deps/proto/osmformat.proto
javac -nowarn --release 17 -cp "$J/protobuf.jar" -d build/osmbin $(find deps/proto/gen -name '*.java')
(cd build/osmbin && jar cf "$ROOT/lib/osmosis-osmbinary-gen.jar" .)

# GraphHopper web-api + core (MaxSpeedCalculator replaced by a stub: it needs a Kotlin library)
CP="$J/jackson-core.jar:$J/jackson-databind.jar:$J/jackson-annotations.jar:$J/jackson-dataformat-xml.jar:$J/stax2-api.jar:$J/jts-core.jar:$J/hppc.jar:$J/protobuf.jar:$J/slf4j-api.jar:$J/xmlgraphics-commons.jar:lib/janino-3.1.9-src.jar:lib/jackson-datatype-jts-src.jar:lib/osmosis-osmbinary-gen.jar"
{ find gh-src/web-api/src/main/java gh-src/core/src/main/java -name '*.java' \
    | grep -v 'gh-src/core/src/main/java/com/graphhopper/routing/util/MaxSpeedCalculator.java$\|parsers/DefaultMaxSpeedParser.java$'
  find build-shim -name '*.java'; } > build/gh-src.txt
rm -rf build/gh && mkdir -p build/gh
javac -nowarn -encoding UTF-8 --release 17 -cp "$CP" -d build/gh @build/gh-src.txt
cp -r gh-src/core/src/main/resources/. build/gh/
[ -d gh-src/web-api/src/main/resources ] && cp -r gh-src/web-api/src/main/resources/. build/gh/
(cd build/gh && jar cf "$ROOT/lib/graphhopper-core-11.0-offline.jar" .)
echo "built lib/graphhopper-core-11.0-offline.jar from $(git -C gh-src rev-parse --short HEAD)"
