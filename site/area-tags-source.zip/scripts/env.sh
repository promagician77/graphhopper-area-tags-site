# Classpath for the offline build: GraphHopper 11.0 compiled from source + Ubuntu library jars.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
J=/usr/share/java
DEPS="$J/jackson-core.jar:$J/jackson-databind.jar:$J/jackson-annotations.jar:$J/jackson-dataformat-xml.jar:$J/stax2-api.jar:$J/jts-core.jar:$J/hppc.jar:$J/protobuf.jar:$J/slf4j-api.jar:$J/slf4j-simple.jar:$J/xmlgraphics-commons.jar"
GHCP="$ROOT/lib/graphhopper-core-11.0-offline.jar:$ROOT/lib/janino-3.1.9-src.jar:$ROOT/lib/jackson-datatype-jts-src.jar:$ROOT/lib/osmosis-osmbinary-gen.jar"
export CP="$DEPS:$GHCP"
export JAVA_TOOL_OPTIONS=
