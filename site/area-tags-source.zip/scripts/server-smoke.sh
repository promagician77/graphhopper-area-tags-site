#!/usr/bin/env bash
# Starts GraphHopper through the PATCHED GraphHopperManaged (Dropwizard's Managed interface and the GTFS class
# are stubbed, the HTTP layer is not run), then sends the old and new POST /route bodies for one journey.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$ROOT"
"$ROOT/scripts/fetch-graphhopper.sh"
rm -rf build/stub build/server /tmp/area-tags-server-graph && mkdir -p build/stub/src/io/dropwizard/lifecycle build/stub/src/com/graphhopper/gtfs build/stub/src/com/graphhopper/http build/stub/classes build/server
printf 'package io.dropwizard.lifecycle;\npublic interface Managed { default void start() throws Exception {} default void stop() throws Exception {} }\n' > build/stub/src/io/dropwizard/lifecycle/Managed.java
printf 'package com.graphhopper.gtfs;\npublic class GraphHopperGtfs extends com.graphhopper.GraphHopper { public GraphHopperGtfs(com.graphhopper.GraphHopperConfig c) {} }\n' > build/stub/src/com/graphhopper/gtfs/GraphHopperGtfs.java
cp gh-src/web-bundle/src/main/java/com/graphhopper/http/GraphHopperManaged.java build/stub/src/com/graphhopper/http/
(cd build/stub/src && patch -s -p5 < "$ROOT/server/patch/graphhopper-11.0-area-tags.patch")
javac -nowarn --release 17 -cp "$CP:lib/areatags.jar" -d build/stub/classes $(find build/stub/src -name '*.java')
javac -nowarn --release 17 -cp "$CP:lib/areatags.jar:build/stub/classes" -d build/server server/src/ServerPatchSmoke.java
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -cp "$CP:lib/areatags.jar:build/stub/classes:build/server" ServerPatchSmoke \
  data/iow.osm.pbf data/areas/areas.geojson /tmp/area-tags-server-graph server/examples
