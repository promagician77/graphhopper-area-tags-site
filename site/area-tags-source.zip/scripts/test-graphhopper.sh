#!/usr/bin/env bash
# Runs GraphHopper 11.0's own core + web-api test suites against this offline build.
# Shows the build routes like upstream before any numbers from it are trusted.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$ROOT"
"$ROOT/scripts/fetch-graphhopper.sh"
J=/usr/share/java
TCP="$CP:$J/hamcrest.jar:$ROOT/build/ghtest"
find gh-src/core/src/test/java gh-src/web-api/src/test/java -name '*.java' \
  | grep -v 'MaxSpeedCalculatorTest\|DefaultMaxSpeedParserTest' > build/ghtest-src.txt   # need the Kotlin library
rm -rf build/ghtest && mkdir -p build/ghtest
javac -nowarn -encoding UTF-8 --release 17 -cp "$CP:$J/junit-platform-console-standalone.jar:$J/hamcrest.jar" -d build/ghtest @build/ghtest-src.txt
cp -r gh-src/core/src/test/resources/. build/ghtest/
cp -r gh-src/web-api/src/test/resources/. build/ghtest/
mkdir -p out
(cd gh-src/core && java -Xmx3g -Dorg.slf4j.simpleLogger.defaultLogLevel=off -jar $J/junit-platform-console-standalone.jar execute \
  -cp "$TCP" --details=summary --disable-banner --disable-ansi-colors --scan-classpath "$ROOT/build/ghtest") > out/graphhopper-tests.txt 2>&1 || true
grep -E "tests (found|successful|failed|skipped|aborted)" out/graphhopper-tests.txt
