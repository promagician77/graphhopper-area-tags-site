#!/usr/bin/env bash
# Runs the plugin's JUnit tests against GraphHopper 11.0.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$ROOT"
"$ROOT/scripts/fetch-graphhopper.sh"
mkdir -p out
TCP="$CP:lib/areatags.jar:/usr/share/java/junit4.jar:/usr/share/java/hamcrest-core.jar"
rm -rf build/test && mkdir -p build/test
javac -nowarn -encoding UTF-8 --release 17 -cp "$TCP" -d build/test $(find areatags/src/test/java -name '*.java')
java -Dorg.slf4j.simpleLogger.defaultLogLevel=error -Dandorra.pbf="$ROOT/gh-src/core/files/andorra.osm.pbf" \
  -cp "$TCP:build/test" org.junit.runner.JUnitCore areatags.AreaTestTest areatags.AreaTagsTest | tee out/plugin-tests.txt
