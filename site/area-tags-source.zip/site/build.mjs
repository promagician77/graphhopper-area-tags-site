// Builds the static site from the measurement files. Every number on the page is read from:
//   site/data/map.json (made by tools/site_data.py from out/results.json + out/site-geo.json)
//   out/*.txt, out/import-timing.json, server/examples/smoke-result.json, server/patch/*.patch, data/extract-info.json
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dist = path.join(here, 'dist');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const D = JSON.parse(read('site/data/map.json'));
const S = D.summary;
const F = S.routing.flexible, L = S.routing.landmarks;
const smoke = JSON.parse(read('server/examples/smoke-result.json'));
const extract = JSON.parse(read('data/extract-info.json'));
const ghTests = read('out/graphhopper-tests.txt');
const pluginTests = read('out/plugin-tests.txt');
const checkOut = read('out/checkgraph.txt').trim();
const patch = read('server/patch/graphhopper-11.0-area-tags.patch');
const after = read('server/examples/request-after-tags.pretty.json');

const num = (re, s) => +(s.match(re) || [0, NaN])[1];
const gh = {
  found: num(/(\d+) tests found/, ghTests), ok: num(/(\d+) tests successful/, ghTests), failed: num(/(\d+) tests failed/, ghTests),
  skipped: num(/(\d+) tests skipped/, ghTests), aborted: num(/(\d+) tests aborted/, ghTests),
};
const pluginCount = num(/OK \((\d+) tests\)/, pluginTests);
if (!(gh.failed === 0 && gh.ok > 2000 && pluginCount > 0)) throw new Error('test results missing or failing');

const n0 = (x) => Math.round(x).toLocaleString('en-GB');
const f1 = (x) => x.toFixed(1), f2 = (x) => x.toFixed(2);
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const J = D.journeys;
const sum = (key, sub) => J.reduce((a, j) => a + j[key][sub], 0);
const visited = { none: sum('visited', 'no_area_rule'), tags: sum('visited', 'precomputed_tags'), poly: sum('visited', 'polygons_in_request') };
const ms = { none: F.totals.no_area_rule.sum_of_medians_ms, tags: F.totals.precomputed_tags.sum_of_medians_ms, poly: F.totals.polygons_in_request.sum_of_medians_ms,
  tagOnly: F.totals.tag_test_only.sum_of_medians_ms };
const perNode = { none: (ms.none * 1000) / visited.none, tags: (ms.tags * 1000) / visited.tags, poly: (ms.poly * 1000) / visited.poly };
const speedup = ms.poly / ms.tags, speedupLM = L.totals.polygons_in_request.sum_of_medians_ms / L.totals.precomputed_tags.sum_of_medians_ms;
const nAreas = S.edge_checks.exact_tags_graph.areas.length;
const edges = S.edge_checks.exact_tags_graph.edges;
const checks = edges * nAreas;
const midWrong = S.edge_checks.middle_point_shortcut.total_mismatches;
const midCarRoads = D.wrong.length;
const midTimeDiff = J.filter((j) => j.mid).length;
const midPath = J.filter((j) => j.mid_path_differs);
const maxVisitRatio = Math.max(...J.map((j) => j.visited.precomputed_tags / j.visited.no_area_rule));
const graphBytesAdded = S.imports.with_area_tags.graph_bytes_on_disk - S.imports.plain.graph_bytes_on_disk;
const imp = S.import_timing;
const payload = S.request_payload;
const areaById = Object.fromEntries(D.areas.map((a) => [a.id, a]));

// ---------- charts ----------
function dumbbell() {
  const W = 680, rowH = 17, top = 34, left = 210, right = 20, H = top + J.length * rowH + 30;
  const lo = Math.log10(0.5), hi = Math.log10(80);
  const x = (v) => left + ((Math.log10(v) - lo) / (hi - lo)) * (W - left - right);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-labelledby="speed-title speed-desc">`;
  for (const g of [0.5, 1, 2, 5, 10, 20, 50]) {
    s += `<line x1="${x(g)}" x2="${x(g)}" y1="${top - 8}" y2="${H - 24}" stroke="#e1e8ea"/>` +
      `<text x="${x(g)}" y="${H - 8}" text-anchor="middle" font-size="12">${g} ms</text>`;
  }
  J.forEach((j, i) => {
    const y = top + i * rowH + rowH / 2;
    const a = j.ms.no_area_rule, b = j.ms.precomputed_tags, c = j.ms.polygons_in_request;
    s += `<text x="${left - 10}" y="${y + 4}" text-anchor="end" font-size="12">${esc(j.id)} ${esc(j.from)} → ${esc(j.to)}</text>`;
    s += `<line x1="${x(Math.min(a, b))}" x2="${x(c)}" y1="${y}" y2="${y}" stroke="#c9d3d7" stroke-width="2"/>`;
    const dot = (v, col, r, label) => `<circle cx="${x(v).toFixed(1)}" cy="${y}" r="${r}" fill="${col}" stroke="#fff" stroke-width="1.5" data-tip="${esc(j.id)} ${esc(j.from)} → ${esc(j.to)}: ${label} ${f1(v)} ms (median of 25)"/>`;
    s += dot(a, '#6b7a83', 4.2, 'no area rule') + dot(b, '#1f5fa8', 4.8, 'area tags') + dot(c, '#a8236f', 4.8, 'polygons in request');
  });
  const y0 = top - 16;
  s += `<text x="${x(J[0].ms.polygons_in_request)}" y="${y0}" text-anchor="middle" font-size="12" font-weight="600" fill="#a8236f">polygons</text>`;
  s += `<text x="${x(J[0].ms.precomputed_tags) + 8}" y="${y0}" text-anchor="start" font-size="12" font-weight="600" fill="#1f5fa8">tags</text>`;
  return s + '</svg>';
}
function bars(rows, unit, maxV, fmt, o = {}) {
  const fs = o.fs || 13, W = 600, rowH = o.rowH || 34, left = o.left || 190, right = o.right || 80, H = rows.length * rowH + 6, bh = o.bh || 18;
  const x = (v) => left + (v / maxV) * (W - left - right);
  const u = unit ? ' ' + unit : '';
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(rows.map((r) => `${r.label}: ${fmt(r.v)}${u}`).join('; '))}">`;
  rows.forEach((r, i) => {
    const y = i * rowH + 6;
    const ty = y + 2 + bh / 2 + fs * 0.35;
    s += `<text x="${left - 10}" y="${ty}" text-anchor="end" font-size="${fs}">${esc(r.label)}</text>`;
    s += `<rect x="${left}" y="${y + 2}" width="${Math.max(2, x(r.v) - left).toFixed(1)}" height="${bh}" rx="2" fill="${r.col}" data-tip="${esc(r.label)}: ${fmt(r.v)}${u}"/>`;
    s += `<text x="${x(r.v) + 6}" y="${ty}" font-size="${fs}" font-weight="600" fill="#14222a">${fmt(r.v)}${u}</text>`;
  });
  return s + '</svg>';
}
function middleDiagramPdf() {
  return `<svg viewBox="0 0 600 200" role="img" aria-label="Edge crossing an area boundary with its middle point outside">
  <rect x="330" y="10" width="262" height="180" fill="rgba(168,35,111,0.08)" stroke="#a8236f" stroke-width="3" stroke-dasharray="10 6"/>
  <text x="580" y="42" text-anchor="end" font-size="26" fill="#a8236f" font-weight="600">area</text>
  <path d="M20 150 L225 118 L430 86" fill="none" stroke="#14222a" stroke-width="6" stroke-linecap="round"/>
  <circle cx="20" cy="150" r="9" fill="#14222a"/><circle cx="430" cy="86" r="9" fill="#14222a"/>
  <circle cx="225" cy="118" r="11" fill="#b56d00" stroke="#fff" stroke-width="3"/>
  <text x="225" y="170" text-anchor="middle" font-size="24" fill="#8a5200" font-weight="600">middle point: outside</text>
  <text x="430" y="130" text-anchor="middle" font-size="24" fill="#14222a">far end: inside</text>
</svg>`;
}
function middleDiagram() {
  return `<svg viewBox="0 0 600 236" role="img" aria-label="A road edge crosses an area boundary. Its middle point is outside, so the built-in lookup says outside; the polygon touches the edge, so request-time areas and the area tags say inside.">
  <rect x="340" y="14" width="244" height="150" fill="rgba(168,35,111,0.08)" stroke="#a8236f" stroke-width="2" stroke-dasharray="8 5"/>
  <text x="572" y="36" text-anchor="end" font-size="13" fill="#a8236f" font-weight="600">area</text>
  <path d="M30 130 L230 104 L430 78" fill="none" stroke="#14222a" stroke-width="4" stroke-linecap="round"/>
  <circle cx="30" cy="130" r="6" fill="#14222a"/><circle cx="430" cy="78" r="6" fill="#14222a"/>
  <circle cx="230" cy="104" r="7" fill="#b56d00" stroke="#fff" stroke-width="2"/>
  <text x="230" y="134" text-anchor="middle" font-size="12.5" fill="#b56d00" font-weight="600">middle point: outside</text>
  <text x="430" y="62" text-anchor="middle" font-size="12.5" fill="#14222a">far end: inside</text>
  <text x="0" y="196" font-size="13" fill="#14222a"><tspan font-weight="600" fill="#1f5fa8">Inside</tspan> for request-time polygons and for the area tags.</text>
  <text x="0" y="220" font-size="13" fill="#14222a"><tspan font-weight="600" fill="#b56d00">Outside</tspan> for GraphHopper's built-in custom_areas lookup.</text>
</svg>`;
}

const tableRows = J.map((j) => `<tr><td>${j.id}</td><td class="l">${esc(j.from)} → ${esc(j.to)}</td><td>${f2(j.tags.km)}</td><td>${f1(j.tags.min)}</td>` +
  `<td>${j.identical ? 'yes' : 'NO'}</td><td>${j.rule_changes_route ? 'yes' : 'no'}</td><td>${f1(j.ms.no_area_rule)}</td><td>${f1(j.ms.precomputed_tags)}</td><td>${f1(j.ms.polygons_in_request)}</td>` +
  `<td>${f2(j.ms.precomputed_tags / j.ms.no_area_rule)}</td><td>${f2(j.ms.tag_test_only / j.ms.no_area_rule)}</td><td>${j.visited.no_area_rule.toLocaleString('en-GB')}</td><td>${j.visited.precomputed_tags.toLocaleString('en-GB')}</td>` +
  `<td>${j.mid ? (j.mid_path_differs ? 'other path' : 'other time') : 'same'}</td></tr>`).join('');

const areaRows = S.edge_checks.exact_tags_graph.areas.map((a, i) => {
  const m = S.edge_checks.middle_point_shortcut.areas[i];
  const ar = areaById[a.id];
  return `<tr><td class="l"><code>${a.encoded_value}</code></td><td class="l">${esc(ar.name)}</td><td>${n0(ar.vertices)}</td><td>${ar.parts}</td><td>${n0(a.edges_inside)}</td><td>${a.mismatches}</td><td>${m.mismatches}</td></tr>`;
}).join('');

const patchHtml = esc(patch.split('\n').filter((l) => !l.startsWith('---') && !l.startsWith('+++')).join('\n'))
  .split('\n').map((l) => (l.startsWith('+') ? `<span class="add">${l}</span>` : l)).join('\n');

// ---------- README (same numbers as the page) ----------
const lmTagOnlyWorst = L.tag_test_only_worst_journey;
const readme = `# Area tags at import for GraphHopper 11.0

Four yes/no tags per road, worked out once at import and used in custom-model conditions
(\`area_newport\` instead of \`in_newport\` plus a polygon). Tested on GraphHopper 11.0, built from its source tag,
with the Isle of Wight OSM extract, four real OSM boundaries and ${J.length} test journeys.

## Results (measured)

| | Flexible mode | Landmarks |
|---|---|---|
| Routes identical to polygons in the request (points, distance, time, weight) | ${F.tags_routes_identical} of ${J.length} | ${L.tags_routes_identical} of ${J.length} |
| Routing time, sum of ${J.length} per-journey medians (25 runs each): polygons | ${n0(ms.poly)} ms | ${n0(L.totals.polygons_in_request.sum_of_medians_ms)} ms |
| Same, area tags | ${n0(ms.tags)} ms | ${n0(L.totals.precomputed_tags.sum_of_medians_ms)} ms |
| Same, no area rule | ${n0(ms.none)} ms | ${n0(L.totals.no_area_rule.sum_of_medians_ms)} ms |
| Tags ÷ no area rule (rule active) | ${f2(F.tags_vs_no_area_total)}×, ${F.journeys_over_1_3x_with_tags} of ${J.length} journeys above 1.3× | ${f2(L.tags_vs_no_area_total)}×, ${L.journeys_over_1_3x_with_tags} of ${J.length} above 1.3× |
| Tag test only ÷ no area rule (statements kept, \`&& false\`) | ${f2(F.tag_test_only_vs_no_area_total)}×, worst journey ${f2(F.tag_test_only_worst_journey)}× | ${f2(L.tag_test_only_vs_no_area_total)}×, worst journey ${f2(lmTagOnlyWorst)}× |
| Roads visited: no area rule / with the area rule | ${n0(visited.none)} / ${n0(visited.tags)} (${f2(visited.tags / visited.none)}×) | |
| Cost per road visited: no rule / tags / polygons | ${f2(perNode.none)} / ${f2(perNode.tags)} / ${f2(perNode.poly)} µs | |

| Check | Result |
|---|---|
| Stored tag vs GraphHopper's request-time test (\`CustomWeightingHelper.in\`), every edge × 4 areas | 0 of ${n0(checks)} disagree |
| GraphHopper's built-in \`custom_areas\` lookup (one middle point per edge), same check | ${n0(midWrong)} disagree (${midCarRoads} car roads); ${midTimeDiff} journeys get another time or distance, ${midPath.length} another path (${midPath.map((j) => j.id).join(', ')}) |
| POST /route body for one journey (Ryde → Easton) | ${n0(smoke.before_body_bytes)} bytes with polygons, ${n0(smoke.after_body_bytes)} with tags; identical route |
| Parsing the custom model JSON (GraphHopper's mapper) | ${payload.polygons_in_request.parse_ms_median} ms with polygons, ${payload.precomputed_tags.parse_ms_median} ms with tags |
| Graph size | edge flags ${S.imports.plain.bytes_for_edge_flags} bytes before and after; +${n0(graphBytesAdded)} bytes on disk |
| Import time (median of 4 alternating runs) | ${(imp.plain_ms_median / 1000).toFixed(2)} s without tags, ${(imp.with_tags_ms_median / 1000).toFixed(2)} s with (within noise) |
| GraphHopper 11.0's own core + web-api tests on this build | ${n0(gh.ok)} passed, ${gh.failed} failed, ${gh.skipped} skipped upstream, ${gh.aborted} stopped by their own assumptions |
| Plugin tests | ${pluginCount} passed |

The rule used: priority ×0.7 in the AONB, ×0.4 in Newport, ×0.2 in Nettlestone and Seaview, speed limit 30 km/h in Ryde,
on GraphHopper's built-in \\\`car.json\\\`. It changes the route on ${F.area_rule_changes_route} of ${J.length} journeys, so a wrong tag would show.

### Measured vs not measured

Measured here: everything in the tables above, on a 2-core Linux sandbox, Java ${S.java}.

Not measured:
- Your UK graph: timings at that size and the 5-second target.
- Your four boundaries, your ${J.length} journeys and your timing script.
- Windows. The code is plain Java with no native parts, but it was only run on Linux.
- A Maven build. \\\`areatags/pom.xml\\\` is written but Maven Central was blocked in the sandbox (see Build notes).
- CH profiles with tag rules (possible, since the tags are ordinary encoded values; not tested).
- The HTTP layer of the web server. The patched \\\`GraphHopperManaged\\\` was run with Dropwizard's \\\`Managed\\\` interface stubbed, fed real POST /route JSON bodies.

## How it works

| Class | Job |
|---|---|
| \\\`AreaTags\\\` | Reads the area GeoJSON once; feature \\\`ulez\\\` becomes encoded value \\\`area_ulez\\\`. Rejects bad names and invalid polygons. |
| \\\`AreaTest\\\` | The yes/no test, matching \\\`CustomWeightingHelper.in\\\`: quick reject on the box of the edge's two end nodes, rectangle shortcut, then "does the polygon touch the edge's full geometry", on coordinates rounded as the graph stores them. |
| \\\`AreaTagParser\\\` | Runs for every edge during import. OSMReader simplifies the geometry, puts it on the way as \\\`point_list\\\`, calls the parsers, then stores that geometry, so the parser tests what routing will test. |
| \\\`AreaTagImportRegistry\\\` | Registers \\\`area_*\\\` as yes/no encoded values with that parser; everything else goes to GraphHopper's default registry. |
| \\\`AreaTagVerifier\\\` / \\\`CheckGraph\\\` | After import, compares every stored tag with GraphHopper's request-time answer. \\\`CheckGraph\\\` is the command-line version (exit code 1 on any difference). |
| \\\`MiddlePointAreaParser\\\` | For comparison only: the built-in \\\`custom_areas\\\` shortcut. |

Encoded value names may not start with \\\`in_\\\` in GraphHopper 11 (\\\`IntEncodedValueImpl.isValidEncodedValue\\\`), hence \\\`area_\\\`.
Changing an area means re-importing, because the answer is stored in the graph.

## Use it with a GraphHopper 11.0 server (Linux or Windows; written, not run here)

1. Check out GraphHopper at tag \\\`11.0\\\` and copy \\\`areatags/src/main/java/areatags\\\` into \\\`web-bundle/src/main/java/\\\`.
2. \\\`git apply server/patch/graphhopper-11.0-area-tags.patch\\\` (five lines in \\\`GraphHopperManaged\\\`; applies cleanly to 11.0).
3. \\\`mvn -DskipTests clean package\\\` (same command in PowerShell).
4. In \\\`config.yml\\\`: \\\`area_tags.file: areas.geojson\\\` and add \\\`area_<id>\\\` for each area to \\\`graph.encoded_values\\\`.
5. Import as usual: \\\`java -jar web/target/graphhopper-web-11.0.jar import config.yml\\\`.
6. Check every edge: \\\`java -cp web/target/graphhopper-web-11.0.jar areatags.CheckGraph graph-cache areas.geojson\\\`.
7. In requests, use \\\`area_<id>\\\` where you used \\\`in_<id>\\\`, and drop \\\`areas\\\`. Example: \\\`server/examples/request-after-tags.pretty.json\\\`.

Area file: a GeoJSON FeatureCollection; each feature has an \\\`id\\\` (lower-case letters, digits, single underscores) and a valid Polygon or MultiPolygon.

## Reproduce the measurements (Linux)

\\\`\\\`\\\`
scripts/build.sh               # plugin + benchmark against lib/graphhopper-core-11.0-offline.jar
scripts/test.sh                # ${pluginCount} plugin tests (JUnit 4)
scripts/test-graphhopper.sh    # GraphHopper's own test suites on this build
scripts/server-smoke.sh        # patched GraphHopperManaged + real request JSON
source scripts/env.sh && java -Xmx3g -cp "\$CP:lib/areatags.jar:lib/bench.jar" bench.Bench \\
  data/iow.osm.pbf data/areas/areas.geojson data/journeys.json /tmp/ghwork out 25
python3 tools/site_data.py . site/data/map.json && (cd site && npm install && node build.mjs)
\\\`\\\`\\\`

Inputs: \\\`data/iow.osm.pbf\\\` (Geofabrik Isle of Wight extract, OSM data of ${extract.osm_timestamp.slice(0, 10)}, sha256 ${extract.sha256.slice(0, 16)}…),
\\\`data/areas/areas.geojson\\\` (four OSM boundary relations: Newport, Ryde, Nettlestone and Seaview, Isle of Wight AONB),
\\\`data/journeys.json\\\` (${J.length} journeys between OSM town and village nodes, picked by \\\`tools/make_journeys.py\\\` with a fixed seed).

## Build notes

The sandbox could reach GitHub and Ubuntu's package archive but not Maven Central, so:
- GraphHopper 11.0 was compiled with javac from the \\\`11.0\\\` git tag (commit 69e50f6) against Ubuntu's jars:
  Jackson 2.14, JTS 1.19, HPPC 0.7.2 (upstream uses 0.8.1), protobuf 3.21, SLF4J 1.7.
- Janino 3.1.9 and jackson-datatype-jts were compiled from their git sources; the OSM PBF classes were generated with protoc
  from the OSM-binary \\\`.proto\\\` files under Osmosis's package name.
- \\\`MaxSpeedCalculator\\\` (needs a Kotlin library) is replaced by a stub that throws if used; it is only used when
  \\\`max_speed_calculator.enabled\\\` is set, which this project never does.
- With that build, GraphHopper's own test suites give ${n0(gh.ok)} passed and ${gh.failed} failed (\\\`out/graphhopper-tests.txt\\\`).

## Data and licences

Map data © OpenStreetMap contributors, ODbL 1.0; extract by Geofabrik. GraphHopper is Apache 2.0.
`.replace(/\\`/g, '`');
fs.writeFileSync(path.join(root, 'README.md'), readme);

// code sample for the client: plugin source, scripts and raw results (no GraphHopper sources, no OSM file)
import { execFileSync } from 'node:child_process';
const zipPath = path.join(here, 'area-tags-source.zip');
fs.rmSync(zipPath, { force: true });
execFileSync('zip', ['-qr', zipPath, 'README.md', 'areatags', 'bench', 'server', 'scripts', 'tools/make_areas.py', 'tools/make_journeys.py',
  'tools/inspect_osm.py', 'tools/site_data.py', 'tools/deploy.mjs', 'data/areas', 'data/journeys.json', 'data/extract-info.json',
  'out/results.json', 'out/import-timing.json', 'out/graphhopper-tests.txt', 'out/plugin-tests.txt', 'out/checkgraph.txt',
  'site/src', 'site/build.mjs', 'site/package.json', '-x', '*/build/*'], { cwd: root });
const zipKB = Math.round(fs.statSync(zipPath).size / 1024);
const html = `<!doctype html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Area tags at import: GraphHopper 11 measured on the Isle of Wight</title>
<meta name="description" content="Four yes/no area tags worked out at import in GraphHopper 11.0, checked against request-time polygons on real UK OSM data: same routes, ${f1(speedup)}× less routing time.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' fill='%23c9dbe2'/%3E%3Cpath d='M6 22 C10 10 18 8 26 12' stroke='%231f5fa8' stroke-width='4' fill='none'/%3E%3Crect x='14' y='6' width='14' height='16' fill='none' stroke='%23a8236f' stroke-width='2.5' stroke-dasharray='4 2'/%3E%3C/svg%3E">
<link rel="preload" href="fonts/archivo-latin-standard-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="app.css">
</head>
<body>
<header class="chart">
  <div class="stage">
    <canvas id="map" tabindex="0" aria-label="Map of the Isle of Wight road network with the four test areas and the selected test route. Arrow keys pan, plus and minus zoom, 0 fits the island."></canvas>
    <p class="loading">Drawing the island</p>
    <div class="zoom"><button id="zoom-in" type="button" aria-label="Zoom in">+</button><button id="zoom-out" type="button" aria-label="Zoom out">−</button><button id="zoom-fit" type="button" aria-label="Show the whole island">⌂</button></div>
    <p class="attrib">Map data © OpenStreetMap contributors, ODbL</p>
  </div>
  <section class="cartouche" aria-labelledby="title">
    <div class="cartouche-inner">
      <h1 id="title">Area tags at import</h1>
      <p class="sub">GraphHopper 11.0, built from its source tag, on real UK roads: the Isle of Wight OSM extract, four real boundaries and ${J.length} test journeys.</p>
      <ul class="findings">
        <li><b>${F.tags_routes_identical} of ${J.length}</b><span>routes identical to the polygon method: every point, distance, time and weight</span></li>
        <li><b>${f1(speedup)}× less</b><span>routing time: ${n0(ms.poly)} ms down to ${n0(ms.tags)} ms over the ${J.length} journeys</span></li>
        <li><b>0 of ${n0(checks)}</b><span>edge checks disagree with GraphHopper's own request-time test</span></li>
        <li><b>${n0(smoke.after_body_bytes)} bytes</b><span>per request instead of ${n0(smoke.before_body_bytes)}: no polygons sent</span></li>
      </ul>
      <p class="by">Built for the GraphHopper area-tags brief by James.</p>
    </div>
  </section>
  <nav class="console" aria-label="Test journeys and map layers">
    <h2>${J.length} test journeys</h2>
    <ul class="journeys" id="journeys"></ul>
    <div class="layers">
      <fieldset>
        <legend>On the map</legend>
        <label><input type="checkbox" id="layer-areas" checked> The four areas</label>
        <label><input type="checkbox" id="layer-none" checked> Route without the area rule</label>
        <label><input type="checkbox" id="layer-wrong"> ${midCarRoads} roads the shortcut gets wrong</label>
        <label>Roads tagged
          <select id="layer-tagged"><option value="">none</option>${D.areas.map((a, i) => `<option value="${i}">area_${a.id}</option>`).join('')}</select>
        </label>
      </fieldset>
    </div>
  </nav>
  <div class="readout" id="readout" aria-live="polite"></div>
</header>

<main>
  <section class="section" id="same">
    <div class="lede">
      <h2>Same routes as the polygons</h2>
      <p>Each of the ${J.length} journeys was routed with the same rule written two ways: polygons sent in the request (<code>in_newport</code>) and tags worked out at import (<code>area_newport</code>). All ${F.tags_routes_identical} pairs match exactly. Every coordinate, the distance, the time and the route weight are identical, in flexible mode and with landmarks (${L.tags_routes_identical} of ${J.length}).</p>
      <p>The test has teeth: the rule changes the route on ${F.area_rule_changes_route} of the ${J.length} journeys compared with no area rule, so a wrong tag would show.</p>
      <p class="note">The rule: priority ×0.7 in the AONB, ×0.4 in Newport, ×0.2 in Seaview, and speed limited to 30 km/h in Ryde, on GraphHopper's own car profile.</p>
    </div>
    <div class="fig">
      <h3>Every edge, every area</h3>
      <p class="cap">After import, each stored tag was compared with GraphHopper's own request-time test (<code>CustomWeightingHelper.in</code>) on the stored geometry.</p>
      <div class="big">
        <div><b>${n0(edges)}</b><span>edges in the graph</span></div>
        <div><b>${n0(checks)}</b><span>edge and area checks</span></div>
        <div><b>0</b><span>disagree</span></div>
      </div>
      <div class="scroll" tabindex="0" role="region" aria-label="Edge checks by area"><table class="data">
        <thead><tr><th class="l">Tag</th><th class="l">Boundary from OSM</th><th>Vertices</th><th>Parts</th><th>Edges inside</th><th>Tags disagree</th><th>Shortcut disagrees</th></tr></thead>
        <tbody>${areaRows}</tbody>
      </table></div>
    </div>
  </section>

  <section class="section" id="speed">
    <div class="lede">
      <h2>${f1(speedup)}× less routing time</h2>
      <p>With polygons in the request, GraphHopper builds a prepared polygon for each area on every request, then tests every edge the search touches against it. With tags, the same check is reading 4 bits already stored on the edge.</p>
      <p>The ${J.length} journeys took ${n0(ms.poly)} ms with polygons and ${n0(ms.tags)} ms with tags (sum of per-journey medians, 25 runs each, flexible mode). The slowest single route fell from ${f1(F.totals.polygons_in_request.slowest_ms)} ms to ${f1(F.totals.precomputed_tags.slowest_ms)} ms. With landmarks the gain was ${f1(speedupLM)}×.</p>
      <p class="note">Before any routing, the polygon request also has ${n0(payload.polygons_in_request.bytes)} bytes of areas JSON to parse: ${f1(payload.polygons_in_request.parse_ms_median)} ms in GraphHopper's own mapper, against ${payload.precomputed_tags.parse_ms_median} ms with tags. That cost is not included above.</p>
    </div>
    <div class="fig">
      <h3 id="speed-title">Routing time per journey, median of 25 runs</h3>
      <p class="cap" id="speed-desc">Flexible mode, log scale. Grey: no area rule. Blue: area tags. Magenta: polygons in the request.</p>
      <ul class="legend"><li><span class="dot" style="background:#6b7a83"></span>No area rule</li><li><span class="dot" style="background:#1f5fa8"></span>Area tags</li><li><span class="dot" style="background:#a8236f"></span>Polygons in request</li></ul>
      ${dumbbell()}
      <details><summary>Table view: all ${J.length} journeys</summary><div class="scroll" tabindex="0" role="region" aria-label="All journeys, table view"><table class="data">
        <thead><tr><th>Id</th><th class="l">Journey</th><th>km</th><th>min</th><th>Same route</th><th>Rule changes route</th><th>ms no rule</th><th>ms tags</th><th>ms polygons</th><th>Tags ÷ no rule</th><th>Tag test only ÷ no rule</th><th>Roads visited, no rule</th><th>Roads visited, rule</th><th>Shortcut</th></tr></thead>
        <tbody>${tableRows}</tbody></table></div></details>
    </div>
  </section>

  <section class="section" id="target">
    <div class="lede">
      <h2>What the 1.3× target is measured against</h2>
      <p>Reading the tags costs almost nothing: ${f2(perNode.tags)} µs per road visited, against ${f2(perNode.none)} µs with no area rule. Polygons cost ${f2(perNode.poly)} µs.</p>
      <p>The rule itself costs more than the check. Lowering priority inside the areas makes the search visit ${f2(visited.tags / visited.none)}× as many roads overall, and up to ${f1(maxVisitRatio)}× on one journey. The same happens with polygons, because the search is identical.</p>
      <p>So the answer depends on the baseline. Tags alone, measured with the same statements switched off (<code>area_newport &amp;&amp; false</code>), came to ${f2(F.tag_test_only_vs_no_area_total)}× overall and at most ${f2(F.tag_test_only_worst_journey)}× on any journey. With the rule active it was ${f2(F.tags_vs_no_area_total)}× overall, and ${F.journeys_over_1_3x_with_tags} of ${J.length} journeys were above 1.3×. All ${F.journeys_over_1_3x_with_tags} were journeys where the rule makes the search visit more roads.</p>
      <p class="note">Your rules and test journeys will decide where this lands. I would agree which baseline counts before quoting a pass.</p>
    </div>
    <div class="fig">
      <h3>Cost per road the search visits</h3>
      <p class="cap">Total routing time ÷ roads visited, over the ${J.length} journeys.</p>
      ${bars([{ label: 'No area rule', v: perNode.none, col: '#6b7a83' }, { label: 'Area tags', v: perNode.tags, col: '#1f5fa8' }, { label: 'Polygons in request', v: perNode.poly, col: '#a8236f' }], 'µs', perNode.poly * 1.05, f2)}
      <h3 style="margin-top:18px">Roads the search visits</h3>
      <p class="cap">Sum over the ${J.length} journeys. Tags and polygons visit exactly the same roads.</p>
      ${bars([{ label: 'No area rule', v: visited.none, col: '#6b7a83' }, { label: 'Rule with tags', v: visited.tags, col: '#1f5fa8' }, { label: 'Rule with polygons', v: visited.poly, col: '#a8236f' }], '', visited.poly * 1.05, n0)}
    </div>
  </section>

  <section class="section" id="shortcut">
    <div class="lede">
      <h2>Why not GraphHopper's built-in custom areas?</h2>
      <p>GraphHopper already reads area files at import (<code>custom_areas.directory</code>). It looks each edge up by one point: its middle point (<code>OSMReader.setArtificialWayTags</code>). Request-time areas instead ask whether the polygon touches the edge anywhere. Wherever an edge crosses or touches a boundary, the two can disagree.</p>
      <p>I built that version too and ran it on the same journeys. ${n0(midWrong)} edges disagreed with the request-time test, ${midCarRoads} of them car roads. ${midTimeDiff} of the ${J.length} journeys came back with a different time or distance, and ${midPath.length} took a different path:</p>
      <ul class="plain">${midPath.map((j) => `<li><button type="button" class="linkish" data-show="${j.id}">${esc(j.from)} → ${esc(j.to)}</button>: ${f2(j.tags.km)} km by polygons, ${f2(j.mid_km)} km by the shortcut</li>`).join('')}</ul>
      <p class="note">The tags here run GraphHopper's own whole-edge test on the stored geometry during import, so they agree by construction, and the check after import proves it.</p>
    </div>
    <div class="fig">
      <h3>One point against the whole edge</h3>
      ${middleDiagram()}
      <p class="cap" style="margin-top:10px">Two more details copied exactly: GraphHopper's quick reject uses the box of the edge's two end nodes only, and the test runs on coordinates rounded to the 1e-7 degree precision the graph stores. Unit tests cover both against <code>CustomWeightingHelper.in</code>, plus over ${n0(15000)} random edges on concave polygons, some with holes.</p>
    </div>
  </section>

  <section class="section" id="plug">
    <div class="lede">
      <h2>How it plugs into your server</h2>
      <p>The plugin is five small Java classes. It registers <code>area_&lt;id&gt;</code> yes/no values and a parser that sets them while edges are created, so you still import with the normal command.</p>
      <p>GraphHopper's web server creates <code>new GraphHopper()</code> itself, so it needs a five-line patch to pass in the area file. Requests then use <code>area_newport</code> where they used <code>in_newport</code>. The prefix cannot be <code>in_</code>, because GraphHopper 11 rejects encoded value names that start with it.</p>
      <p>The four tags fit in spare bits: edge flags stayed at ${S.imports.with_area_tags.bytes_for_edge_flags} bytes and the graph grew by ${n0(graphBytesAdded)} bytes. Import time on the island was ${(imp.plain_ms_median / 1000).toFixed(1)} s without tags and ${(imp.with_tags_ms_median / 1000).toFixed(1)} s with them, which is within run-to-run noise.</p>
    </div>
    <div class="fig">
      <p class="file">web-bundle/…/GraphHopperManaged.java (patch applies cleanly to the 11.0 tag)</p>
      <pre tabindex="0" aria-label="Server patch">${patchHtml.trim()}</pre>
      <div class="cols2">
        <div><p class="file">config.yml</p><pre tabindex="0" aria-label="config.yml lines">area_tags.file: areas.geojson
graph.encoded_values: car_access,
  car_average_speed, road_access,
  area_newport, area_ryde,
  area_aonb, area_seaview</pre></div>
        <div><p class="file">After import: check every edge</p><pre tabindex="0" aria-label="Check command output">${esc(checkOut.split('\n').map((l) => l.replace(/\s+edges inside\s+/, ' in, ').replace(/\s{2,}/g, ' ')).join('\n'))}</pre></div>
      </div>
      <p class="file">POST /route body after the change (${n0(smoke.after_body_bytes)} bytes compact; before: ${n0(smoke.before_body_bytes)})</p>
      <pre tabindex="0" aria-label="Request body after the change">${esc(after)}</pre>
    </div>
  </section>

  <section class="section" id="trust">
    <div class="lede">
      <h2>Checks on the build itself</h2>
      <p>My sandbox cannot reach Maven Central, so GraphHopper 11.0 was compiled from its git tag against Ubuntu's library jars, including HPPC 0.7.2 instead of 0.8.1. Before trusting any timing from it, I ran GraphHopper's own test suites on this build.</p>
      <p class="note">The only source not compiled is the optional legal-speed calculator, which needs a Kotlin library; it is off by default and was replaced by a stub that fails if called.</p>
    </div>
    <div class="fig">
      <ul class="checks">
        <li><b>${n0(gh.ok)} pass</b><span>GraphHopper 11.0's own core and web-api tests on this build: ${gh.failed} failed, ${gh.skipped} skipped upstream, ${gh.aborted} stopped by their own assumptions (for example "loop shortcuts only exist for edge-based CH").</span></li>
        <li><b>${pluginCount} pass</b><span>Plugin tests: crossing, touching, bending and rounded edges, rectangles, holes and multipolygons, random edges, bad names and invalid polygons, plus a second dataset (Andorra, from GraphHopper's test files) with 0 disagreements.</span></li>
        <li><b>Identical</b><span>The patched <code>GraphHopperManaged</code> started from a server-style config and answered real POST /route JSON bodies: ${smoke.journey.replace('->', '→')}, ${f2(smoke.km)} km, same route before and after.</span></li>
        <li><b>${extract.osm_timestamp.slice(0, 10)}</b><span>Isle of Wight extract from Geofabrik, ${(extract.bytes / 1e6).toFixed(1)} MB, ${n0(S.imports.plain.nodes)} junctions and ${n0(edges)} edges. Boundaries are OSM relations: three civil parishes and the AONB.</span></li>
      </ul>
    </div>
  </section>

  <section class="section" id="measured">
    <div class="lede">
      <h2>Measured, and not yet</h2>
      <p>Everything above came from the scripts in the download, on a 2-core Linux sandbox with Java ${esc(S.java)}.</p>
      <p><a href="area-tags-source.zip" download>Plugin source, tests, scripts and raw results</a> (zip, ${zipKB} KB). The OSM extract is not included; the README says where it comes from.</p>
    </div>
    <div class="fig cols2">
      <div>
        <h3>Measured here</h3>
        <ul class="plain">
          <li>Route equality on ${J.length} journeys, flexible and landmarks</li>
          <li>Every edge's tag against GraphHopper's request-time test</li>
          <li>Routing time, 25 runs per request in shuffled order</li>
          <li>Cost of the tag check apart from the rule's effect</li>
          <li>The middle-point shortcut, edge by edge and route by route</li>
          <li>The server path, through the real patch and real request JSON</li>
        </ul>
      </div>
      <div>
        <h3>Not measured yet</h3>
        <ul class="plain">
          <li>Your UK graph: timings at that size, and the 5-second target</li>
          <li>Your four boundaries, 27 journeys and timing script</li>
          <li>Windows: the code is plain Java, but I ran it on Linux only</li>
          <li>A Maven build: the <code>pom.xml</code> is written but Maven Central was blocked here</li>
          <li>CH profiles: possible with tags, not tested</li>
        </ul>
      </div>
    </div>
  </section>
</main>
<footer>
  <p>Map and road data © OpenStreetMap contributors, available under the Open Database Licence. Extract by Geofabrik (OSM data as of ${extract.osm_timestamp.slice(0, 10)}). GraphHopper is Apache 2.0 licensed. This page is not affiliated with GraphHopper GmbH.</p>
</footer>
<script src="app.js"></script>
</body>
</html>`;

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'fonts'), { recursive: true });
fs.mkdirSync(path.join(dist, 'data'), { recursive: true });
fs.writeFileSync(path.join(dist, 'index.html'), html);
fs.copyFileSync(path.join(here, 'src/app.css'), path.join(dist, 'app.css'));
fs.copyFileSync(path.join(here, 'src/app.js'), path.join(dist, 'app.js'));
fs.copyFileSync(path.join(here, 'data/map.json'), path.join(dist, 'data/map.json'));
fs.copyFileSync(zipPath, path.join(dist, 'area-tags-source.zip'));
const fonts = [
  ['@fontsource-variable/archivo/files/archivo-latin-standard-normal.woff2', 'archivo-latin-standard-normal.woff2'],
  ['@fontsource/newsreader/files/newsreader-latin-500-normal.woff2', 'newsreader-latin-500-normal.woff2'],
  ['@fontsource/newsreader/files/newsreader-latin-400-italic.woff2', 'newsreader-latin-400-italic.woff2'],
];
for (const [src, dst] of fonts) fs.copyFileSync(path.join(here, 'node_modules', src), path.join(dist, 'fonts', dst));



// ---------- 2-page PDF brief (rendered to PDF by tools/qa/pdf.cjs; no price, no timeline) ----------
const pdfDir = path.join(here, 'pdf');
fs.mkdirSync(pdfDir, { recursive: true });
for (const [src, dst] of [['@fontsource-variable/archivo/files/archivo-latin-standard-normal.woff2', 'archivo.woff2'],
  ['@fontsource/newsreader/files/newsreader-latin-500-normal.woff2', 'newsreader-500.woff2'], ['@fontsource/newsreader/files/newsreader-latin-400-italic.woff2', 'newsreader-italic.woff2']])
  fs.copyFileSync(path.join(here, 'node_modules', src), path.join(pdfDir, dst));
const pdfHtml = `<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><title>Area tags at import: GraphHopper 11.0</title>
<style>
@font-face{font-family:Archivo;src:url(archivo.woff2) format("woff2");font-weight:100 900;font-stretch:62% 125%}
@font-face{font-family:Newsreader;src:url(newsreader-500.woff2) format("woff2");font-weight:500}
@font-face{font-family:Newsreader;src:url(newsreader-italic.woff2) format("woff2");font-weight:400;font-style:italic}
@page{size:A4;margin:0}
*{box-sizing:border-box}
body{margin:0;font-family:Archivo,Arial,sans-serif;color:#14222a;font-size:9.1pt;line-height:1.42;font-variant-numeric:tabular-nums;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{width:210mm;height:297mm;padding:11mm 12mm 9mm;overflow:hidden;position:relative;page-break-after:always;display:flex;flex-direction:column;gap:3.2mm}
.page:last-child{page-break-after:auto}
h1{font-family:Newsreader,Georgia,serif;font-style:italic;font-weight:400;font-size:27pt;line-height:1;margin:0}
h2{font-family:Newsreader,Georgia,serif;font-weight:500;font-size:13pt;line-height:1.15;margin:0 0 1.6mm}
p{margin:0 0 1.6mm}
.sub{color:#435259;font-size:9.6pt;margin:1.6mm 0 0}
.top{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:1.2pt solid #14222a;padding-bottom:2.4mm}
.top .who{font-size:8pt;color:#5d6b72;text-align:right;white-space:nowrap}
.res{display:grid;grid-template-columns:repeat(4,1fr);border-bottom:.6pt solid #b7c4c9}
.res div{padding:1.4mm 3mm 2.2mm 0}
.res div+div{padding-left:3mm;border-left:.6pt solid #b7c4c9}
.res b{display:block;font-stretch:76%;font-size:17pt;line-height:1.1}
.res span{font-size:8pt;color:#435259;line-height:1.3;display:block}
.map{border:.8pt solid #14222a;height:100mm;overflow:hidden;position:relative}
.map img{width:100%;height:100%;object-fit:cover;display:block}
.cap{font-size:7.8pt;color:#435259;margin-top:1mm}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:6mm}
ol{margin:0;padding-left:4.6mm}ol li{margin:0 0 1.2mm}
ul{margin:0;padding-left:4mm}ul li{margin:0 0 .9mm}
code{font-family:Menlo,Consolas,monospace;font-size:7.8pt}
svg{width:100%;height:auto;display:block}
svg text{font-family:Archivo,Arial,sans-serif;fill:#435259}
.box{border:.6pt solid #b7c4c9;padding:2.6mm 3mm}
.legend{display:flex;gap:5mm;font-size:8pt;margin:0 0 1mm}
.dot{display:inline-block;width:2.4mm;height:2.4mm;border-radius:50%;margin-right:1.2mm;vertical-align:-.2mm}
.foot{margin-top:auto;font-size:7pt;color:#5d6b72;border-top:.6pt solid #b7c4c9;padding-top:1.4mm}
.k{font-weight:650}
</style></head><body>
<section class="page">
  <div class="top"><div><h1>Area tags at import</h1>
    <p class="sub">GraphHopper 11.0 on real UK roads: the Isle of Wight OSM extract, four OSM boundaries and ${J.length} test journeys.</p></div>
    <div class="who">Prepared by James<br>for the GraphHopper area-tags brief</div></div>
  <div class="res">
    <div><b>${F.tags_routes_identical} of ${J.length}</b><span>routes identical to polygons in the request: points, distance, time, weight</span></div>
    <div><b>${f1(speedup)}× less</b><span>routing time: ${n0(ms.poly)} ms to ${n0(ms.tags)} ms over ${J.length} journeys</span></div>
    <div><b>0 of ${n0(checks)}</b><span>edge checks disagree with GraphHopper's request-time test</span></div>
    <div><b>${n0(smoke.after_body_bytes)} bytes</b><span>per request body instead of ${n0(smoke.before_body_bytes)}</span></div>
  </div>
  <div><div class="map"><img src="map.png" alt="Isle of Wight road network, the four areas and the St Helens to Calbourne route"></div>
  <p class="cap">St Helens → Calbourne. Blue: route with area tags, identical to the polygon route (magenta dashes). Amber band: GraphHopper's built-in middle-point lookup, which takes another road (${f2(J.find((j) => j.id === 'J22').mid_km)} km instead of ${f2(J.find((j) => j.id === 'J22').tags.km)} km). Magenta outlines: the four areas. Map data © OpenStreetMap contributors.</p></div>
  <div class="cols">
    <div><h2>The approach</h2><ol>
      <li>Register four yes/no encoded values, <code>area_&lt;id&gt;</code>, through GraphHopper's <code>ImportRegistry</code>.</li>
      <li>While each edge is created, run GraphHopper's own whole-edge test on the geometry it stores: end-node box, rectangle shortcut, then "does the polygon touch the edge".</li>
      <li>After import, compare every stored tag with the request-time answer. Any difference fails the check.</li>
      <li>Requests use <code>area_newport</code> instead of <code>in_newport</code> and send no polygons. The web server needs a five-line patch to load the area file.</li>
      <li>Run your ${J.length} journeys and timing script: routes first, then timings against the baseline we agree.</li>
    </ol></div>
    <div><h2>Why not the built-in custom areas</h2>
      <p>GraphHopper's <code>custom_areas.directory</code> looks each edge up by its middle point. Request-time areas test the whole edge, so edges that cross a boundary can disagree.</p>
      ${middleDiagramPdf()}
      <p style="margin-top:1.4mm">Measured with that shortcut: <span class="k">${n0(midWrong)} edges</span> disagreed (${midCarRoads} car roads). ${midTimeDiff} of ${J.length} journeys got another time or distance, and ${midPath.length} took another path.</p>
    </div>
  </div>
  <div class="foot">GraphHopper 11.0 compiled from its source tag; its own test suites: ${n0(gh.ok)} passed, ${gh.failed} failed. OSM extract by Geofabrik, data of ${extract.osm_timestamp.slice(0, 10)}, ODbL. Page 1 of 2.</div>
</section>
<section class="page">
  <div><h2>Routing time per journey, median of 25 runs (flexible mode, log scale)</h2>
  <div class="legend"><span><span class="dot" style="background:#6b7a83"></span>No area rule</span><span><span class="dot" style="background:#1f5fa8"></span>Area tags</span><span><span class="dot" style="background:#a8236f"></span>Polygons in request</span></div>
  ${dumbbell()}
  <p class="cap">Polygon requests also parse ${n0(payload.polygons_in_request.bytes)} bytes of area JSON first (${f1(payload.polygons_in_request.parse_ms_median)} ms), which is not included. With landmarks the gain was ${f1(speedupLM)}×.</p></div>
  <div class="cols">
    <div class="box"><h2>What 1.3× is measured against</h2>
      ${bars([{ label: 'No area rule', v: perNode.none, col: '#6b7a83' }, { label: 'Area tags', v: perNode.tags, col: '#1f5fa8' }, { label: 'Polygons', v: perNode.poly, col: '#a8236f' }], 'µs', perNode.poly * 1.3, f2, { fs: 24, rowH: 44, bh: 30, left: 200, right: 110 })}
      <p style="margin-top:1.4mm">Reading the tags adds almost nothing per road visited. The rule itself makes the search visit ${f2(visited.tags / visited.none)}× as many roads, up to ${f1(maxVisitRatio)}× on one journey.</p>
      <p>Tag check alone: <span class="k">${f2(F.tag_test_only_vs_no_area_total)}×</span>, at most ${f2(F.tag_test_only_worst_journey)}×. With the rule active: <span class="k">${f2(F.tags_vs_no_area_total)}×</span>, with ${F.journeys_over_1_3x_with_tags} of ${J.length} journeys above 1.3×, all because of extra roads visited.</p></div>
    <div class="box"><h2>Checks</h2><ul>
      <li><span class="k">${n0(gh.ok)} passed, ${gh.failed} failed:</span> GraphHopper 11.0's own core and web-api tests on this build.</li>
      <li><span class="k">${pluginCount} passed:</span> plugin tests, covering crossing, touching, bending and rounded edges, holes, multipolygons, random edges, and a second dataset (Andorra) with 0 disagreements.</li>
      <li><span class="k">Same route:</span> the patched server class answered real POST /route bodies before and after the change.</li>
      <li><span class="k">Graph cost:</span> edge flags stayed ${S.imports.plain.bytes_for_edge_flags} bytes; import time unchanged within noise.</li>
    </ul></div>
  </div>
  <div class="cols">
    <div><h2>Measured here</h2><ul>
      <li>Route equality on ${J.length} journeys, flexible and landmarks</li>
      <li>Every edge's tag against the request-time test</li>
      <li>Routing time, 25 runs per request, shuffled order</li>
      <li>Tag check cost apart from the rule's effect on the search</li>
      <li>The middle-point shortcut, edge by edge and route by route</li></ul></div>
    <div><h2>Not measured yet</h2><ul>
      <li>Your UK graph: timings at that size and the 5-second target</li>
      <li>Your boundaries, journeys and timing script</li>
      <li>Windows (plain Java; run on Linux only)</li>
      <li>A Maven build (Maven Central was blocked; javac build used)</li>
      <li>CH profiles with tag rules</li></ul></div>
  </div>
  <div class="foot">Rule tested: priority ×0.7 in the AONB, ×0.4 in Newport, ×0.2 in Nettlestone and Seaview, 30 km/h limit in Ryde, on GraphHopper's car profile. It changes ${F.area_rule_changes_route} of ${J.length} routes. Boundaries are OSM relations. Map data © OpenStreetMap contributors, ODbL. Page 2 of 2.</div>
</section></body></html>`;
fs.writeFileSync(path.join(pdfDir, 'brief.html'), pdfHtml);

console.log('built', dist, { speedup: speedup.toFixed(2), checks, gh });
